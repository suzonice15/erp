-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 18, 2019 at 12:33 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `erpcodeigniter`
--

-- --------------------------------------------------------

--
-- Table structure for table `academic_class_teacher`
--

CREATE TABLE `academic_class_teacher` (
  `id` int(10) NOT NULL,
  `teacher_id` varchar(20) NOT NULL,
  `class_id` int(3) NOT NULL,
  `year` varchar(4) NOT NULL,
  `from_date` varchar(16) NOT NULL,
  `to_date` varchar(16) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `academic_class_teacher`
--

INSERT INTO `academic_class_teacher` (`id`, `teacher_id`, `class_id`, `year`, `from_date`, `to_date`, `status`) VALUES
(1, '17001', 4, '2017', '2018-01-03', '2018-06-28', 1);

-- --------------------------------------------------------

--
-- Table structure for table `academic_enroll_class`
--

CREATE TABLE `academic_enroll_class` (
  `id` int(10) NOT NULL,
  `student_id` varchar(200) NOT NULL,
  `class_roll` varchar(10) NOT NULL,
  `class_id` int(6) NOT NULL,
  `shift_id` int(2) NOT NULL,
  `section_id` int(4) NOT NULL,
  `study_group_id` int(10) NOT NULL,
  `year` varchar(4) NOT NULL,
  `status` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `academic_enroll_class`
--

INSERT INTO `academic_enroll_class` (`id`, `student_id`, `class_roll`, `class_id`, `shift_id`, `section_id`, `study_group_id`, `year`, `status`) VALUES
(1, '1801001', '1', 1, 1, 3, 1, '2018', '1'),
(2, '1803001', '1', 3, 1, 3, 2, '2018', '1'),
(3, '1804001', '1', 4, 1, 3, 1, '2018', '1'),
(4, '1804003', '2', 4, 1, 3, 1, '2018', '1'),
(5, '1804002', '3', 4, 1, 4, 2, '2018', '1'),
(6, '1806002', '1', 6, 1, 3, 1, '2018', '1'),
(7, '1806001', '2', 6, 1, 3, 3, '2018', '1');

-- --------------------------------------------------------

--
-- Table structure for table `academic_fourth_subject`
--

CREATE TABLE `academic_fourth_subject` (
  `id` int(10) NOT NULL,
  `student_id` varchar(10) NOT NULL,
  `subject_id` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `academic_fourth_subject`
--

INSERT INTO `academic_fourth_subject` (`id`, `student_id`, `subject_id`) VALUES
(1, '180001', 2),
(2, '180002', 2),
(3, '180003', 2),
(4, '180004', 2),
(5, '180001', 2);

-- --------------------------------------------------------

--
-- Table structure for table `academic_studentinfo`
--

CREATE TABLE `academic_studentinfo` (
  `id` int(10) NOT NULL,
  `student_id` varchar(100) NOT NULL,
  `student_name` varchar(200) NOT NULL,
  `picture` varchar(100) NOT NULL,
  `class_id` int(10) NOT NULL,
  `study_group_id` int(10) NOT NULL,
  `shift_id` int(10) NOT NULL,
  `section_id` int(10) NOT NULL,
  `fourth_subject_id` int(10) NOT NULL,
  `gender_id` int(10) NOT NULL,
  `religion_id` int(10) NOT NULL,
  `nationality` varchar(50) NOT NULL,
  `date_of_birth` varchar(20) NOT NULL,
  `blood_group_id` int(10) NOT NULL,
  `present_address` varchar(500) NOT NULL,
  `permanent_address` varchar(500) NOT NULL,
  `student_mobile_no` varchar(16) NOT NULL,
  `student_email` varchar(50) NOT NULL,
  `father_name` varchar(200) NOT NULL,
  `father_occupation` varchar(100) NOT NULL,
  `father_nid` varchar(100) NOT NULL,
  `father_mobile_no` varchar(16) NOT NULL,
  `father_email` varchar(50) NOT NULL,
  `mother_name` varchar(100) NOT NULL,
  `mother_occupation` varchar(100) NOT NULL,
  `mother_nid` varchar(100) NOT NULL,
  `mother_mobile_no` varchar(16) NOT NULL,
  `mother_email` varchar(50) NOT NULL,
  `guardian_type` int(10) NOT NULL,
  `previous_school_name` varchar(200) NOT NULL,
  `tc` varchar(50) NOT NULL,
  `guardian_name` varchar(100) NOT NULL,
  `guardian_nid` varchar(50) NOT NULL,
  `guardian_email` varchar(50) NOT NULL,
  `guardian_mobile_no` varchar(16) NOT NULL,
  `guardian_address` varchar(500) NOT NULL,
  `guardian_occupation` varchar(100) NOT NULL,
  `relation_with_student` varchar(100) NOT NULL,
  `status` int(10) NOT NULL,
  `payment_status` int(10) NOT NULL,
  `admission_date` varchar(16) NOT NULL,
  `admission_by` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `academic_studentinfo`
--

INSERT INTO `academic_studentinfo` (`id`, `student_id`, `student_name`, `picture`, `class_id`, `study_group_id`, `shift_id`, `section_id`, `fourth_subject_id`, `gender_id`, `religion_id`, `nationality`, `date_of_birth`, `blood_group_id`, `present_address`, `permanent_address`, `student_mobile_no`, `student_email`, `father_name`, `father_occupation`, `father_nid`, `father_mobile_no`, `father_email`, `mother_name`, `mother_occupation`, `mother_nid`, `mother_mobile_no`, `mother_email`, `guardian_type`, `previous_school_name`, `tc`, `guardian_name`, `guardian_nid`, `guardian_email`, `guardian_mobile_no`, `guardian_address`, `guardian_occupation`, `relation_with_student`, `status`, `payment_status`, `admission_date`, `admission_by`) VALUES
(1, '1801001', 'shoriful Islam', '08-12-2017_1512758941.jpg', 1, 1, 1, 1, 0, 0, 0, '', '', 0, '', '', '01557268139', 'shorifulislam35169@gmail.com', 'Altaf Hossain', '0', '0', '0', '0', '0', '0', '0', '0', '0', 0, '', '', '', '', '', '', '', '', '', 1, 0, '2018-10-07', ''),
(2, '1804001', 'huzaifa bin shorif', '09-10-2018_1539058461.jpg', 4, 1, 1, 1, 2, 2, 2, 'fdg', '2018-09-04', 5, 'gdsfg', 'sdfgdfsgdf', 'sdfgsdf', 'gsdfgdsfg', 'sdfg', 'dsfgsd', 'fgsdfg', 'sdg', 'sdgfsd', 'fgsdfg', 'sdgfds', 'fgdsf', 'gdsgdsfg', 'sdg', 2, 'dsfgdsfg', 'dsgdsf', 'dsfgdsf', 'dsfgdfs', 'dfsgdfs', 'gdfsg', 'gdsg', 'gdsf', 'dfsgdfs', 1, 0, '2018-10-07', ''),
(3, '1804002', 'karim bin asad', '08-09-2018_1536400271.jpg', 4, 2, 1, 4, 2, 1, 3, 'dgdsg', '2018-09-05', 6, 'gdfsg', 'dsgfdsf', 'sdfgdsf', 'gdfsgdfgdf', 'sdfg', 'dsfgdsf', 'gdfs', 'sdgdsf', 'gdsfgd', 'fgdfgdf', 'gdsg', 'dsgdf', 'gdsgdfg', 'dsg', 2, 'dsfgdfs', 'gdsfgd', 'dsfgdsf', 'sgdsfg', 'gdsg', 'dsfgd', 'dsg', 'gdsfgds', 'dsgdf', 1, 0, '2018-10-07', ''),
(4, '1806001', 'fgdsfg', '08-09-2018_1536397453.jpg', 6, 3, 1, 3, 2, 3, 3, 'dsfgfd', '2018-09-04', 6, 'dfs', 'gdsfgdfs', 'sdfgsdfg', 'dsfgdfsg', 'sdfgdsf', 'gdsfg', 'dsfgdsf', 'dsfgdsf', 'dsgdsfg', 'gdsfg', '', '', '', 'sdfg', 2, 'dgdsfg', 'dsfgdf', 'dsgdsf', 'fdfgdf', 'dfsgdf', 'sgdsg', 'yttyu', 'gdsfg', 'tyuuuuuuuuuuutyt', 1, 0, '2018-10-07', ''),
(5, '1804003', 'fdgdsf', '08-09-2018_1536400194.jpg', 4, 1, 1, 3, 2, 2, 2, 'dsfgd', '2018-09-04', 6, 'dsfg', 'sdfgdsf', 'dsfgdsf', 'gdsfgdf', 'dsfg', 'dsfgdsf', 'gdsfg', 'sdfgds', 'fgdsfgd', 'sfgdsfgdfs', 'dfsgdsf', 'gdsfg', 'sdfgdsfg', 'dfsg', 3, 'dsfgdsf', 'gdsfg', 'dsfg', 'gdsf', 'gdsfg', 'dsfgdfs', 'dsfg', 'dsfgdsf', 'dsfgdf', 1, 0, '2018-10-07', ''),
(6, '1803001', 'fgdfsg', '08-09-2018_1536404467.jpg', 3, 2, 1, 3, 2, 3, 2, 'rey', '2018-09-10', 7, 'rreytry', 'reyryrt', 'y', 'rtyrtyrt', 'reyrt', 'rtyrt', 'rty', 'ty', 'ttrt', 'ytr', 'ery', 'trr', 't', 'rey', 3, 'rerey', 'ryrey', 'rey', 'rtyrt', 'rtyrt', 'yry', 'yrreyrt', 'r', 'tytyr', 1, 0, '2018-10-07', ''),
(7, '1806002', 'Abul kalam', '07-10-2018_1538898172.jpg', 6, 1, 1, 3, 2, 1, 1, 'Bangladeshi', '2018-10-30', 4, 'sadasdasdas', 'asdas', '016757876543', 'sgo@gmail.com', 'aziz', 'dhaka', '78967785656', '01556765432', 'fa@gmail.com', 'hjkhjas', 'sadasd', 'sadasdas', '096478325632', 'sdasd', 1, 'sadasds', '56565sad', 'asdas', 'asdas', 'asdasasd', 'asdas', 'asdasdas', 'asdas', 'asdasdas', 1, 0, '2018-10-07', '1');

-- --------------------------------------------------------

--
-- Table structure for table `academic_subject_teacher`
--

CREATE TABLE `academic_subject_teacher` (
  `id` int(10) NOT NULL,
  `teacher_id` varchar(20) NOT NULL,
  `class_id` int(3) NOT NULL,
  `subject_id` int(6) NOT NULL,
  `shift_id` int(3) NOT NULL,
  `section_id` int(4) NOT NULL,
  `year` varchar(4) NOT NULL,
  `from_date` varchar(16) NOT NULL,
  `to_date` varchar(16) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `academic_subject_teacher`
--

INSERT INTO `academic_subject_teacher` (`id`, `teacher_id`, `class_id`, `subject_id`, `shift_id`, `section_id`, `year`, `from_date`, `to_date`, `status`) VALUES
(1, '17001', 6, 2, 1, 3, '2018', '2018-10-01', '2018-10-31', 1),
(2, '17001', 5, 2, 1, 3, '2018', '2018-10-01', '2018-10-31', 1),
(3, '17002', 5, 2, 1, 3, '2018', '2018-10-02', '2018-10-23', 1);

-- --------------------------------------------------------

--
-- Table structure for table `account_admission_fee`
--

CREATE TABLE `account_admission_fee` (
  `id` int(10) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `class_id` int(10) NOT NULL,
  `year` varchar(4) NOT NULL,
  `payment_date` varchar(12) NOT NULL,
  `paid_amount` varchar(20) NOT NULL,
  `due_amount` varchar(20) NOT NULL,
  `user_id` varchar(20) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account_admission_fee`
--

INSERT INTO `account_admission_fee` (`id`, `student_id`, `class_id`, `year`, `payment_date`, `paid_amount`, `due_amount`, `user_id`, `status`) VALUES
(1, '1801001', 1, '2018', '2018-09-15', '5000', '0', 'admin', 1),
(2, '1801002', 1, '2018', '2018-09-15', '5000', '0', 'admin', 1),
(3, '1802003', 2, '2018', '2018-09-15', '5000', '0', 'admin', 1),
(4, '1802004', 2, '2018', '2018-09-15', '5000', '0', 'admin', 1),
(5, '1803005', 3, '2018', '2018-09-15', '10000', '0', 'admin', 1),
(6, '1803006', 3, '2018', '2018-09-14', '10000', '0', 'admin', 1),
(7, '1804002', 4, '2018', '2018-10-13', '40008', '0', 'admin', 1),
(8, '1804002', 4, '2018', '2018-10-13', '7876', '0', 'admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `account_exam_fee`
--

CREATE TABLE `account_exam_fee` (
  `id` int(10) NOT NULL,
  `student_id` int(10) NOT NULL,
  `class_id` int(10) NOT NULL,
  `shift_id` int(10) NOT NULL,
  `section_id` int(10) NOT NULL,
  `year` varchar(4) NOT NULL,
  `academic_exam_id` int(10) NOT NULL,
  `amount` int(10) NOT NULL,
  `payment_date` varchar(20) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account_exam_fee`
--

INSERT INTO `account_exam_fee` (`id`, `student_id`, `class_id`, `shift_id`, `section_id`, `year`, `academic_exam_id`, `amount`, `payment_date`, `user_id`, `status`) VALUES
(1, 1801001, 1, 1, 1, '2018', 1, 5007, '2018-10-11', 'admin', 2),
(2, 1801002, 1, 1, 3, '2018', 1, 9006, '2018-10-13', 'admin', 2),
(3, 1804001, 4, 1, 3, '2018', 1, 3000, '2018-10-15', 'admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `exam_result`
--

CREATE TABLE `exam_result` (
  `id` int(10) NOT NULL,
  `student_id` varchar(60) NOT NULL,
  `class_id` int(10) NOT NULL,
  `subject_id` int(10) NOT NULL,
  `shift_id` int(10) NOT NULL,
  `section_id` int(10) NOT NULL,
  `academic_exam_id` int(10) NOT NULL,
  `study_group_id` int(10) NOT NULL,
  `year` int(4) NOT NULL,
  `subjective_marks` varchar(4) NOT NULL,
  `objective_marks` varchar(4) NOT NULL,
  `practical_marks` varchar(4) NOT NULL,
  `result_created_by` varchar(10) NOT NULL,
  `publish_status` int(2) NOT NULL,
  `block_status` int(2) NOT NULL,
  `activity_status` int(2) NOT NULL COMMENT '1=add,2=update',
  `activity_date` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_result`
--

INSERT INTO `exam_result` (`id`, `student_id`, `class_id`, `subject_id`, `shift_id`, `section_id`, `academic_exam_id`, `study_group_id`, `year`, `subjective_marks`, `objective_marks`, `practical_marks`, `result_created_by`, `publish_status`, `block_status`, `activity_status`, `activity_date`) VALUES
(1, '1804001', 1, 1, 1, 1, 1, 1, 2020, '20', '20', '20', 'admin', 0, 1, 2, '2018-10-11'),
(2, '1801001', 1, 2, 1, 3, 1, 1, 2018, '30', '30', '30', 'admin', 0, 1, 1, '2018-10-12');

-- --------------------------------------------------------

--
-- Table structure for table `hr_academic`
--

CREATE TABLE `hr_academic` (
  `id` int(10) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `exam_degree_id` int(10) NOT NULL,
  `grade_marks` varchar(20) NOT NULL,
  `academic_session` varchar(20) NOT NULL,
  `year_of_passing` varchar(14) NOT NULL,
  `institute` varchar(200) NOT NULL,
  `study_group_id` int(10) NOT NULL,
  `board_id` int(10) NOT NULL,
  `exam_name_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_academic`
--

INSERT INTO `hr_academic` (`id`, `emp_id`, `exam_degree_id`, `grade_marks`, `academic_session`, `year_of_passing`, `institute`, `study_group_id`, `board_id`, `exam_name_id`) VALUES
(1, '17001', 8, 'B', 'B', 'B', 'B', 3, 7, 2),
(2, '17001', 1, '5.00', '2000-2002', '2002', 'DD', 1, 1, 1),
(3, '17001', 1, '5.00', '2000-2002', '2002', 'DD', 1, 1, 1),
(4, '17001', 7, 'A', 'A', 'A', 'A', 2, 8, 1),
(5, '17001', 4, 'A', 'A', 'A', 'A', 2, 8, 1),
(6, '17002', 3, 'B', 'B', 'B', 'B', 3, 9, 1),
(7, '17002', 3, 'B', 'B', 'B', 'B', 3, 9, 1),
(8, '17003', 4, 'B', 'B', 'B', 'B', 1, 8, 1),
(9, '1703', 5, 'A', 'A', 'A', 'A', 1, 8, 2),
(10, '17004', 1, 'A', 'A', 'A', 'A', 2, 8, 1),
(11, '17004', 4, 'B', 'B', 'B', 'B', 1, 8, 2),
(12, '17005', 1, '800', '2000-2001', '2003', 'gfdhfdgh', 1, 1, 2),
(13, '17005', 1, '850', '2003-2004', '2005', 'fghfdghfg', 2, 9, 2),
(14, '17010', 1, '880', '2001', '2001', 'gdsf', 2, 9, 1),
(15, '17010', 1, '890', '2001-2002', '2000', 'sdfgdsfgdf', 2, 8, 1),
(16, '17010', 4, '780', '2001-2001', '2003', 'bxcbfghdfg', 3, 8, 2),
(17, '17005', 7, '34', '34', '3444', '34wer', 2, 8, 2),
(18, '17005', 1, 'werwe', 'werwe', 'ewrew', 'werwe', 2, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `hr_additional_and_deduction`
--

CREATE TABLE `hr_additional_and_deduction` (
  `id` int(10) NOT NULL,
  `emp_id` varchar(20) NOT NULL,
  `department_id` int(10) NOT NULL,
  `shift_id` int(10) NOT NULL,
  `section_id` int(10) NOT NULL,
  `year` varchar(6) NOT NULL,
  `month` varchar(4) NOT NULL,
  `amount` varchar(20) NOT NULL,
  `type` int(2) NOT NULL COMMENT '1=additional, 2= deduction',
  `additional_and_deduction_type` int(2) NOT NULL COMMENT 'if type =1,1=arrear,2-other, or type=2 then 1=advance,2=overdrawn,3=other''s',
  `remarks` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_additional_and_deduction`
--

INSERT INTO `hr_additional_and_deduction` (`id`, `emp_id`, `department_id`, `shift_id`, `section_id`, `year`, `month`, `amount`, `type`, `additional_and_deduction_type`, `remarks`) VALUES
(1, '17001', 1, 1, 1, '20018', '01', '50000', 1, 1, 'ok'),
(2, '17002', 4, 1, 3, '2018', '02', '657675', 1, 1, 'dfghdf'),
(3, '17003', 5, 1, 3, '2018', '02', '1000', 2, 1, 'ghjfgjfgjfg'),
(4, '17004', 5, 1, 3, '2018', '02', '5000', 1, 1, 'l\';kl\'l;k');

-- --------------------------------------------------------

--
-- Table structure for table `hr_assigning_dept_head`
--

CREATE TABLE `hr_assigning_dept_head` (
  `id` int(10) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `department_id` int(10) NOT NULL,
  `start_date` varchar(14) NOT NULL,
  `end_date` varchar(14) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_assigning_dept_head`
--

INSERT INTO `hr_assigning_dept_head` (`id`, `user_id`, `department_id`, `start_date`, `end_date`, `status`) VALUES
(2, '17002', 4, '2018-01-03', '2018-01-31', 1),
(3, '17003', 2, '2018-01-01', '2018-01-31', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hr_assigning_roster`
--

CREATE TABLE `hr_assigning_roster` (
  `id` int(10) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `from_date` varchar(14) NOT NULL,
  `to_date` varchar(14) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_assigning_roster`
--

INSERT INTO `hr_assigning_roster` (`id`, `emp_id`, `from_date`, `to_date`, `status`) VALUES
(1, '17001', '2018-01-01', '2018-01-31', 1),
(2, '17002', '2018-01-01', '2018-01-31', 0),
(3, '17004', '2018-01-01', '2018-01-31', 0),
(4, '17005', '2018-01-01', '2018-01-31', 0),
(5, '17006', '2018-01-01', '2018-01-31', 0),
(6, '17008', '2018-01-01', '2018-01-31', 0),
(7, '17007', '2018-01-01', '2018-01-31', 1),
(8, '17003', '2018-01-01', '2018-01-31', 1),
(9, '17002', '2018-02-01', '2018-02-22', 0),
(10, '17004', '2018-02-01', '2018-02-28', 0),
(11, '17005', '2018-02-01', '2018-02-28', 0),
(12, '17006', '2018-02-01', '2018-02-28', 0),
(13, '17008', '2018-02-01', '2018-02-28', 0),
(14, '17002', '2018-10-24', '2019-02-28', 1),
(15, '17004', '2018-10-24', '2019-02-28', 1),
(16, '17005', '2018-10-24', '2019-02-28', 1),
(17, '17006', '2018-10-24', '2019-02-28', 1),
(18, '17008', '2018-10-24', '2019-02-28', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hr_assigning_weekend`
--

CREATE TABLE `hr_assigning_weekend` (
  `id` int(10) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `from_date` varchar(16) NOT NULL,
  `to_date` varchar(16) NOT NULL,
  `weekend_id` int(10) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_assigning_weekend`
--

INSERT INTO `hr_assigning_weekend` (`id`, `emp_id`, `from_date`, `to_date`, `weekend_id`, `status`) VALUES
(1, '17001', '2018-01-01', '2018-04-31', 1, 1),
(24, '17002', '2017-01-01', '2017-12-31', 6, 1),
(2, '17002', '2018-01-01', '2018-01-31', 2, 0),
(7, '17002', '2018-02-01', '2018-02-28', 1, 0),
(12, '17002', '2018-03-01', '2018-03-31', 3, 0),
(17, '17002', '2018-04-01', '2018-04-11', 7, 0),
(22, '17003', '2018-02-28', '2018-02-27', 5, 1),
(25, '17004', '2017-01-01', '2017-12-31', 6, 1),
(3, '17004', '2018-01-01', '2018-01-31', 2, 0),
(8, '17004', '2018-02-01', '2018-02-28', 1, 0),
(13, '17004', '2018-03-01', '2018-03-31', 3, 0),
(18, '17004', '2018-04-01', '2018-04-30', 2, 0),
(26, '17005', '2017-01-01', '2017-12-31', 6, 1),
(4, '17005', '2018-01-01', '2018-01-31', 2, 0),
(9, '17005', '2018-02-01', '2018-02-28', 1, 0),
(14, '17005', '2018-03-01', '2018-03-31', 3, 0),
(19, '17005', '2018-04-01', '2018-04-30', 2, 0),
(27, '17006', '2017-01-01', '2017-12-31', 6, 1),
(5, '17006', '2018-01-01', '2018-01-31', 2, 0),
(10, '17006', '2018-02-01', '2018-02-28', 1, 0),
(15, '17006', '2018-03-01', '2018-03-31', 3, 0),
(20, '17006', '2018-04-01', '2018-04-30', 2, 0),
(28, '17008', '2017-01-01', '2017-12-31', 6, 1),
(6, '17008', '2018-01-01', '2018-01-31', 2, 0),
(11, '17008', '2018-02-01', '2018-02-28', 1, 0),
(16, '17008', '2018-03-01', '2018-03-31', 3, 0),
(21, '17008', '2018-04-01', '2018-04-30', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `hr_attendance`
--

CREATE TABLE `hr_attendance` (
  `id` int(10) NOT NULL,
  `emp_id` int(10) NOT NULL,
  `present_date` varchar(16) NOT NULL,
  `in_time` varchar(16) DEFAULT NULL,
  `out_time` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_attendance`
--

INSERT INTO `hr_attendance` (`id`, `emp_id`, `present_date`, `in_time`, `out_time`) VALUES
(3, 17002, '2018-01-07', '10:10', '6:00'),
(8, 17002, '2018-01-08', '10:00', '6:00'),
(13, 17002, '2018-01-09', '10:00', '6:00'),
(18, 17002, '2018-01-10', '10:00', '6:00'),
(23, 17002, '2018-01-11', '10:00', '6:00'),
(28, 17002, '2018-02-03', '10:00', '17:00'),
(4, 17004, '2018-01-07', '10:10', '6:00'),
(9, 17004, '2018-01-08', '10:00', '6:00'),
(14, 17004, '2018-01-09', '10:00', '6:00'),
(19, 17004, '2018-01-10', '10:00', '6:00'),
(24, 17004, '2018-01-11', '10:00', '6:00'),
(29, 17004, '2018-02-03', '10:00', '17:00'),
(5, 17005, '2018-01-07', '10:10', '6:00'),
(10, 17005, '2018-01-08', '10:00', '6:00'),
(15, 17005, '2018-01-09', '10:00', '6:00'),
(20, 17005, '2018-01-10', '10:00', '6:00'),
(25, 17005, '2018-01-11', '10:00', '6:00'),
(30, 17005, '2018-02-03', '10:00', '17:00'),
(6, 17006, '2018-01-07', '10:10', '6:00'),
(11, 17006, '2018-01-08', '10:00', '6:00'),
(16, 17006, '2018-01-09', '10:00', '6:00'),
(21, 17006, '2018-01-10', '10:00', '6:00'),
(26, 17006, '2018-01-11', '10:00', '6:00'),
(31, 17006, '2018-02-03', '10:00', '17:00'),
(7, 17008, '2018-01-07', '10:10', '6:00'),
(12, 17008, '2018-01-08', '10:00', '6:00'),
(17, 17008, '2018-01-09', '10:00', '6:00'),
(22, 17008, '2018-01-10', '10:00', '6:00'),
(27, 17008, '2018-01-11', '10:00', '6:00'),
(32, 17008, '2018-02-03', '10:00', '17:00');

-- --------------------------------------------------------

--
-- Table structure for table `hr_award_and_honors`
--

CREATE TABLE `hr_award_and_honors` (
  `id` int(10) NOT NULL,
  `emp_id` int(50) NOT NULL,
  `award_honors_title` varchar(100) NOT NULL,
  `awards_type` int(2) NOT NULL,
  `country` varchar(100) NOT NULL,
  `receiving_date` varchar(14) NOT NULL,
  `organization_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_award_and_honors`
--

INSERT INTO `hr_award_and_honors` (`id`, `emp_id`, `award_honors_title`, `awards_type`, `country`, `receiving_date`, `organization_name`) VALUES
(1, 17004, 'Book fire', 2, 'Bangladesh', '2018-01-01', 'Book'),
(2, 17001, 'Golobar warming', 2, 'India', '2000-01-01', 'KSDK'),
(3, 17001, 'Award', 1, 'Bangladesh', '2003-01-01', 'DITT'),
(4, 17004, 'Book', 2, 'BD', '2018-01-18', 'Book'),
(5, 17002, 'Test data2', 2, 'fdhgfh', '', 'fgh'),
(6, 17003, 'gfj', 1, 'fgjh', '2018-01-04', 'gjhg'),
(7, 17003, 'gfjf', 2, 'ggfj', '2018-01-11', 'gfjfgjg'),
(8, 17010, 'fdgdfsg', 2, 'dfsgsdf', '2018-02-06', 'dfgsdfgfd'),
(9, 17010, 'dfghfdsg', 2, 'fdgsdfgdsf', '2018-02-07', 'sdfgdsfgdf'),
(10, 17010, 'sdfgsdfg', 1, 'sdfgsdfgsdf', '2018-02-23', 'sdfgsdfgd'),
(11, 17005, 'test data', 2, 'usa', '2018-10-02', 'ssssuuu'),
(12, 17005, 'sdfsdfds', 2, 'sdfsdf', '2018-10-23', 'sdfsdfsd');

-- --------------------------------------------------------

--
-- Table structure for table `hr_basic`
--

CREATE TABLE `hr_basic` (
  `id` int(10) NOT NULL,
  `emp_name` varchar(100) NOT NULL,
  `emp_id` varchar(20) NOT NULL,
  `emp_nid` varchar(30) NOT NULL,
  `mobile_no1` varchar(16) NOT NULL,
  `email_address` varchar(60) NOT NULL,
  `date_of_birth` varchar(16) NOT NULL,
  `gender_id` int(10) NOT NULL,
  `division_id` int(10) NOT NULL,
  `district_id` int(10) NOT NULL,
  `thana_id` int(10) NOT NULL,
  `father_name` varchar(100) NOT NULL,
  `mother_name` varchar(100) NOT NULL,
  `passport_number` varchar(60) NOT NULL,
  `passport_number_exp_date` varchar(16) NOT NULL,
  `birth_certificate` varchar(30) NOT NULL,
  `present_address` varchar(500) NOT NULL,
  `permanent_address` varchar(500) NOT NULL,
  `profile_picture` varchar(100) NOT NULL,
  `blood_group_id` int(10) NOT NULL,
  `religion_id` int(10) NOT NULL,
  `freedom_fighter_family` int(2) NOT NULL,
  `freedom_fighter_relation_id` int(10) NOT NULL,
  `freedom_fighter_id` varchar(30) NOT NULL,
  `signature` varchar(100) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_basic`
--

INSERT INTO `hr_basic` (`id`, `emp_name`, `emp_id`, `emp_nid`, `mobile_no1`, `email_address`, `date_of_birth`, `gender_id`, `division_id`, `district_id`, `thana_id`, `father_name`, `mother_name`, `passport_number`, `passport_number_exp_date`, `birth_certificate`, `present_address`, `permanent_address`, `profile_picture`, `blood_group_id`, `religion_id`, `freedom_fighter_family`, `freedom_fighter_relation_id`, `freedom_fighter_id`, `signature`, `status`) VALUES
(1, 'Khan ataur rahman', '17004', '756756', '01557268135', 'a4@gmail.com', '2017-12-01', 2, 3, 2, 5, 'dsfgsad', 'fsdfs', '67', '2017-12-28', '54654', 'dsgdsfgsdf', 'sdfgdsfgsdfg', '08-12-2017_1512758911.jpg', 0, 3, 1, 2, '6576', '08-12-2017_1512758911.png', 1),
(2, 'Shoriful', '17001', '5675476575', '546475', 'a1@gmail.com', '2017-12-07', 2, 3, 2, 4, 'dfgdsfg', 'dsgsdfgds', '563754', '', '7657567', 'fdhdgf', 'dhgfghfg', '08-12-2017_1512758820.jpg', 3, 3, 1, 1, '657856', '08-12-2017_1512758820.png', 1),
(3, 'Tamanna Khan', '17002', '54645373665', '4565', 'a2@gmail.com', '2017-12-13', 2, 3, 2, 4, 'dgsdfsg', 'dsfgdsf', '', '', 'sdfgdsf', 'gsdfgsd', 'fgsdfgsdfg', '08-12-2017_1512758848.jpg', 4, 3, 1, 2, '6765', '08-12-2017_15127588481.jpg', 1),
(4, 'Kazi sirazum monir', '17003', '213456123123', '67', 'a3@gmail.com', '2017-12-07', 2, 3, 2, 5, 'sdg', 'fdsgdsfgfd', '567', '2017-12-27', '564756', 'dhfgh', 'gfhd', '08-12-2017_1512758941.jpg', 6, 2, 1, 2, '678567', '09-12-2017_1512792899.png', 1),
(5, 'fdgdsf', '17005', '567537657', '6576', 'a5@gmail.com', '2017-12-09', 1, 3, 2, 3, 'ghd', 'fgfgf', '678776', '2017-12-28', '6547567', 'tyuty', 'gfhd', '09-12-2017_1512793707.jpg', 4, 3, 0, 0, '', '09-12-2017_1512793707.png', 1),
(6, 'grty', '17006', '6587', '765876', 'a6@gmail.com', '2017-12-07', 2, 3, 2, 2, 'fdsg', 'dsfgsdfg', '67868', '2017-12-28', '56744', 'fdhfgh', 'hg', '09-12-2017_1512793805.jpg', 3, 2, 1, 1, '67567', '09-12-2017_15127938051.jpg', 1),
(7, 'Jarin sultan', '17007', '75665657', '7546756', 'a7@gmail.com', '2017-12-07', 2, 3, 2, 4, 'sadfasd', 'fasdf', 'dg6756', '2017-12-27', 'fhdf', 'dfhfggf', 'dfhfg', '09-12-2017_1512794157.jpg', 6, 3, 0, 0, '', '09-12-2017_15127941571.jpg', 1),
(8, 'Alam uddin', '17008', 'htryutyrt', '6554', 'a8@gmail.com', '2017-12-06', 1, 3, 2, 3, 'xcvbcxvbcxv', 'bxcbcxv', 'xcvbcxvbvc', '2017-12-07', 'xcvbcxvbcvx', 'xcvbcvxbvcx', 'xcvbcxvb', '09-12-2017_1512794228.jpg', 3, 3, 0, 0, '', '09-12-2017_1512794228.png', 1),
(9, 'Asraful alam', '17009', '67', 'd5657567', 'a9@gmail.com', '2017-12-14', 1, 3, 2, 4, 'dfgh', 'gdf', 'gdfgh', '2017-12-28', '67456', '75hfghgh', 'dfghfg', '09-12-2017_1512794296.jpg', 6, 1, 0, 0, '', '09-12-2017_15127942961.jpg', 1),
(10, 'Istiak', '17010', '6575567', '6757465', 'a10@gmail.com', '2017-12-27', 1, 3, 2, 5, 'dsfgdsfg', 'dsfgdsfgdsdf', '65756', '2017-12-07', 'dfhdfh', 'dfghdfghgf', 'dghd', '09-12-2017_1512794414.jpg', 3, 1, 1, 1, '57654756756756756', '09-12-2017_15127944141.jpg', 1),
(11, 'Mishon Ali', '17011', '76575', '765756', 'a11@gmail.com', '2017-12-13', 1, 3, 2, 5, 'dsgfds', 'gsdfg', 'dfs', '2017-12-22', 'sdfg', 'dsfgdfg', 'fdsgdsfgdf', '09-12-2017_1512794608.jpg', 4, 1, 0, 0, '', '09-12-2017_15127946081.jpg', 1),
(12, 'Imran alam', '17012', '567565', '7657', 'a12@gmail.com', '2017-12-07', 1, 3, 2, 4, 'sdgdfs', 'gdsfg', 'dfg', '2017-12-21', '57567', 'dfhdfgh', 'hdfgh', '09-12-2017_1512794695.jpg', 5, 1, 1, 1, '56756754675', '09-12-2017_1512794695.png', 1),
(13, 'Sohag Khan', '17013', '7567567', '67465', 'a13@gmail.com', '2017-12-06', 1, 3, 2, 4, 'dsfgsdf', 'gsdfgdsf', 'sdfg', '2017-12-07', 'sdfgsdf', 'gsdfgsdfg', 'dfsgdsgdsf', '09-12-2017_1512794802.jpg', 6, 3, 0, 0, '', '09-12-2017_15127948021.jpg', 1),
(14, 'Sahana parvin', '17014', '567567', '6575567', 'a14@gmail.com', '2017-12-06', 1, 3, 2, 4, 'dsfgdsf', 'gdfsgds', '567', '2017-12-28', 'fgfdgds', 'fgsdf', 'gsdfgdsf', '09-12-2017_1512795046.jpg', 2, 4, 0, 0, '', '09-12-2017_15127950461.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hr_bonus`
--

CREATE TABLE `hr_bonus` (
  `id` int(10) NOT NULL,
  `department_id` int(10) NOT NULL,
  `shift_id` int(10) NOT NULL,
  `section_id` int(10) NOT NULL,
  `bonus_type_id` int(10) NOT NULL,
  `amount_type` int(10) NOT NULL COMMENT '1=fifed,2=percent of basic',
  `amount` varchar(10) NOT NULL,
  `year` varchar(6) NOT NULL,
  `month` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_bonus`
--

INSERT INTO `hr_bonus` (`id`, `department_id`, `shift_id`, `section_id`, `bonus_type_id`, `amount_type`, `amount`, `year`, `month`) VALUES
(1, 1, 1, 1, 1, 1, '50000', '2017', 1),
(2, 5, 1, 3, 1, 2, '45', '2018', 1),
(3, 4, 1, 3, 1, 2, '50', '2018', 1),
(4, 3, 2, 5, 1, 1, '200000', '2018', 1),
(5, 2, 1, 3, 1, 2, '30', '2018', 2);

-- --------------------------------------------------------

--
-- Table structure for table `hr_child`
--

CREATE TABLE `hr_child` (
  `id` int(10) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `child_name` varchar(200) NOT NULL,
  `gender_id` int(10) NOT NULL,
  `profession_id` int(10) NOT NULL,
  `class` varchar(60) NOT NULL,
  `institute` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_child`
--

INSERT INTO `hr_child` (`id`, `emp_id`, `child_name`, `gender_id`, `profession_id`, `class`, `institute`) VALUES
(1, '17001', 'Huzaifa Bin Sharif', 1, 1, 'Class One', 'DDI'),
(2, '17001', 'Huzaifa', 3, 5, 'Class Two', 'DD'),
(3, '17001', 'KK', 3, 5, 'Class Three', 'DD'),
(4, '17002', 'LL', 2, 5, 'Class Four', 'DD'),
(5, '17003', 'Kalam', 3, 5, 'Class Five', 'KK'),
(6, '17003', 'LL', 3, 5, 'Class Six', 'DD'),
(7, '17005', 'ghjg', 2, 4, 'gfhj', 'fgjhgfh'),
(8, '17005', 'gjhgh', 1, 3, 'fghj', 'fgjhfg'),
(9, '17010', 'hfghfgdfg', 2, 4, 'fghdfgh', 'fghgfg'),
(10, '17010', 'fghfghf', 1, 4, 'fghfgfg', 'fghfg'),
(16, '17005', 'uu', 2, 4, 'yuy', 'uii'),
(17, '17005', 'huzaifa', 1, 5, 'one', 'iit');

-- --------------------------------------------------------

--
-- Table structure for table `hr_contact`
--

CREATE TABLE `hr_contact` (
  `id` int(10) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `present_address` varchar(500) NOT NULL,
  `present_post_office` varchar(100) NOT NULL,
  `present_post_code` varchar(10) NOT NULL,
  `present_division_id` int(10) NOT NULL,
  `present_district_id` int(10) NOT NULL,
  `present_thana_id` int(10) NOT NULL,
  `present_email` varchar(100) NOT NULL,
  `present_phone` varchar(20) NOT NULL,
  `present_mobile` varchar(20) NOT NULL,
  `is_address_same` int(2) NOT NULL,
  `permanent_address` varchar(200) NOT NULL,
  `permanent_post_office` varchar(11) NOT NULL,
  `permanent_post_code` varchar(11) NOT NULL,
  `permanent_division_id` int(11) NOT NULL,
  `permanent_district_id` int(11) NOT NULL,
  `permanent_thana_id` int(11) NOT NULL,
  `permanent_email` varchar(60) NOT NULL,
  `permanent_phone` varchar(16) NOT NULL,
  `permanent_mobile` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_contact`
--

INSERT INTO `hr_contact` (`id`, `emp_id`, `present_address`, `present_post_office`, `present_post_code`, `present_division_id`, `present_district_id`, `present_thana_id`, `present_email`, `present_phone`, `present_mobile`, `is_address_same`, `permanent_address`, `permanent_post_office`, `permanent_post_code`, `permanent_division_id`, `permanent_district_id`, `permanent_thana_id`, `permanent_email`, `permanent_phone`, `permanent_mobile`) VALUES
(1, '17001', 'A', 'A', 'A', 3, 2, 6, 'A', 'AA', 'A', 2, 'A', 'A', 'A', 3, 2, 3, 'A', 'A', 'A'),
(2, '17002', 'A', 'A', 'A', 1, 1, 1, 'A', 'A', 'A', 1, 'A', 'A', 'A', 1, 1, 1, 'A', 'A', 'A'),
(3, '17002', 'D', 'D', 'D', 3, 2, 6, 'D', 'D', 'D', 2, 'H', 'H', 'H', 3, 2, 5, 'H', 'H', 'H'),
(4, '17003', 'U', 'U', 'U', 3, 2, 4, 'U', 'U', 'U', 1, '', '', '', 0, 0, 0, '', '', ''),
(5, '17004', 'fdghfh', '5656', '56765', 3, 2, 5, 'e@gmail.com', '56756765', '654756', 2, 'tyu', 'yrtu', 'ytyuty', 3, 2, 5, 'tyur', '67865', '67867'),
(6, '17005', 'g', 'g', 'g', 3, 2, 6, 'f', 'f', 'f', 1, '', '', '', 0, 0, 0, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `hr_co_curricular_activities`
--

CREATE TABLE `hr_co_curricular_activities` (
  `id` int(10) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_co_curricular_activities`
--

INSERT INTO `hr_co_curricular_activities` (`id`, `emp_id`, `description`) VALUES
(1, '17001', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(2, '17002', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(3, '17003', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(4, '17004', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(5, '17005', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(6, '17006', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(7, '17007', '<span style=\"background-color:rgb(245, 245, 245); font-family:helvetica neue,helvetica,arial,sans-serif; font-size:14px\">ver since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</span>'),
(8, '17007', '<span style=\"background-color:rgb(245, 245, 245); font-family:helvetica neue,helvetica,arial,sans-serif; font-size:14px\">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</span>'),
(9, '17008', '<span style=\"background-color:rgb(245, 245, 245); font-family:helvetica neue,helvetica,arial,sans-serif; font-size:14px\">ver since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.ver since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem I'),
(10, '17010', 'ghjgh ghj ghjghj gfjhg gfhjghj'),
(11, '17005', 'test data testda ta a a');

-- --------------------------------------------------------

--
-- Table structure for table `hr_create_salary`
--

CREATE TABLE `hr_create_salary` (
  `id` int(10) NOT NULL,
  `emp_id` varchar(100) NOT NULL,
  `emp_name` varchar(1000) NOT NULL,
  `department` varchar(100) NOT NULL,
  `shift` varchar(10) NOT NULL,
  `section` varchar(10) NOT NULL,
  `joining_date` varchar(20) NOT NULL,
  `days_of_month` varchar(10) NOT NULL,
  `days_of_attend` varchar(10) NOT NULL,
  `days_of_weekend` varchar(10) NOT NULL,
  `days_of_holiday` varchar(10) NOT NULL,
  `days_of_medical` int(11) NOT NULL,
  `days_of_casual_leave` varchar(10) NOT NULL,
  `days_of_metarnity_leave` varchar(10) NOT NULL,
  `days_of_absent` varchar(10) NOT NULL,
  `total_payable_days` varchar(10) NOT NULL,
  `basic_salary` varchar(100) NOT NULL,
  `house_rent` varchar(10) NOT NULL,
  `medical` varchar(10) NOT NULL,
  `conveyance` varchar(10) NOT NULL,
  `arrear` varchar(10) NOT NULL,
  `extra_duty` varchar(100) NOT NULL,
  `other` varchar(10) NOT NULL,
  `total_addition` varchar(100) NOT NULL,
  `tax` varchar(100) NOT NULL,
  `provident_fund` varchar(100) NOT NULL,
  `charge_allowance` varchar(100) NOT NULL,
  `welfare_fund` varchar(100) NOT NULL,
  `other_deduction` varchar(100) NOT NULL,
  `loan` varchar(100) NOT NULL,
  `advance` varchar(100) NOT NULL,
  `absent` varchar(100) NOT NULL,
  `stamp` varchar(10) NOT NULL,
  `deduction_total` varchar(100) NOT NULL,
  `net_payable_total` varchar(100) NOT NULL,
  `payment_type` int(2) NOT NULL,
  `year` varchar(4) NOT NULL,
  `month` varchar(4) NOT NULL,
  `salary_type_id` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hr_experience`
--

CREATE TABLE `hr_experience` (
  `id` int(10) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `institute` varchar(200) NOT NULL,
  `business` varchar(200) NOT NULL,
  `department` varchar(200) NOT NULL,
  `joined_on` varchar(16) NOT NULL,
  `release_on` varchar(16) NOT NULL,
  `duration` varchar(10) NOT NULL,
  `area_of_concentration` varchar(500) NOT NULL,
  `position_hold` varchar(100) NOT NULL,
  `job_details` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_experience`
--

INSERT INTO `hr_experience` (`id`, `emp_id`, `institute`, `business`, `department`, `joined_on`, `release_on`, `duration`, `area_of_concentration`, `position_hold`, `job_details`) VALUES
(1, '17001', 'dsfgg', 'dsg', 'dfgdf', '2018-01-01', '2018-01-20', '20', 'gdfgfdgdf', 'dsfgdfg', 'dsfgdfgdf'),
(2, '17001', 'fdgdf', 'gdsfgfdsg', 'fdsgdfs', '2018-01-01', '2018-01-31', '8', 'dgh', 'fghf', ''),
(3, '17003', 'fdgh', 'fghfgh', 'fgh', '2018-01-31', '2018-01-30', '2', 'dfghfg', 'hfdgh', 'fghdfhfghfgh'),
(4, '17003', 'ng', 'jghj', 'gjghj', '2018-01-01', '2018-01-02', '2', 'gfjhhg', 'jhg', ''),
(5, '17004', 'ghjgfjh', 'gfjhghj', 'gfjhh', '2018-01-04', '2018-01-06', '3', 'gjfgjg', 'hgh', 'jhghgh'),
(6, '17005', 'fghfg', 'hfdhfg', 'hfghdfgh', '2016-01-01', '2018-12-31', '1096', 'fghgfg', 'hgfg', ''),
(7, '17005', 'hfdghg', 'fgfggfh', 'ghggf', '2016-01-08', '2018-01-24', '748', 'gfh', 'gfg', 'fghfg gh gh ghghgfhfg'),
(8, '17006', 'bvcvb ', 'gfjgh', 'fgjhhg', '2017-01-01', '2018-01-24', '389', 'gjh', 'ghj', ''),
(9, '17006', 'ghj', 'hg', 'jgfjhfgj', '2018-01-03', '2018-01-31', '29', 'fgj', 'h', 'jhgj'),
(10, '17007', 'fghfdghd', 'fhdfhdf', 'hfdhfdhfg', '2018-01-01', '2018-01-31', '31', 'fdgh', 'ffhfgh', ''),
(11, '17007', 'gfhgh ', 'gfhghghfgh', 'ghjh', '2015-11-30', '2018-01-30', '793', 'hgjg', 'gjgfjghgfh', 'fgjgfgh'),
(12, '17008', 'jh', 'gfh', 'gfjhfg', '2018-02-01', '2018-02-28', '28', 'fgjfgj', 'gfgjhgfhjgfh', 'fgjhhg'),
(13, '17008', 'gfhf', 'fghfg', 'hfdghfd', '2018-02-27', '2018-02-28', '2', 'fhfd', 'gfd', 'fghfdghfdghfd'),
(14, '17010', 'ghfghfg', 'dfghgfg', 'fdghfghfg', '2018-02-06', '2018-02-07', '2', 'fghfghf', 'ghfdghfg', ''),
(15, '17010', 'dgh', 'gfdg', 'fgdfhg', '2018-02-06', '2018-02-28', '23', 'dfh', 'gdfghg', 'ghfdghdfgf'),
(16, '17005', 'd', 'd', 'd', '2018-10-22', '2018-10-24', '3 years', 'd', 'd', ''),
(17, '17005', 'd', 'd', 'd', '2018-10-16', '2018-10-31', '16', 'd', 'd', 'd'),
(18, '17005', 'dxfsd', 'sdfsadf', 'asdfsdfsd', '2018-10-03', '2018-10-31', '29', 'asdfsd', 'asdfssadfasdasdfsadfsadsadfsda', 'dsfadsfs'),
(19, '17005', 'test data', 'test data', 'test data', '2018-10-02', '2018-10-31', '30', 'h', 'h', 'jkdsfhksdjhf'),
(20, '17005', 'u', 'u', 'u', '2018-10-17', '2018-10-31', '15', 'q', 'q', 'q');

-- --------------------------------------------------------

--
-- Table structure for table `hr_family`
--

CREATE TABLE `hr_family` (
  `id` int(10) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `spouse_name` varchar(100) NOT NULL,
  `profession_id` int(10) NOT NULL,
  `organization` varchar(200) NOT NULL,
  `designation_id` int(10) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `total_family_members` int(4) NOT NULL,
  `no_of_other_dependents` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_family`
--

INSERT INTO `hr_family` (`id`, `emp_id`, `spouse_name`, `profession_id`, `organization`, `designation_id`, `contact_no`, `total_family_members`, `no_of_other_dependents`) VALUES
(1, '17001', 'sdfasdf', 1, 'dfgfd', 1, '5654645645', 10, 5),
(2, '17002', 'Bonni', 4, 'house', 2, '345432543', 12, 12),
(3, '17002', 'gfdg', 4, 'dsfgdf', 2, '565', 50, 5),
(4, '17003', 'dsfgdsf', 4, 'sdfgdsf', 1, '567657', 6, 5),
(5, '17004', 'a', 5, 'sdgfd', 3, '546546', 12, 12),
(6, '17005', 'B', 4, 'DD', 2, '123456', 11, 2),
(7, '17006', 'fdhd', 4, 'dfhgf', 3, '6786786', 7, 7),
(8, '17007', 'ghjfg', 4, 'fgjhgfh', 2, '768', 8, 8),
(9, '17010', 'dfgdsfgdf', 4, 'sdfgdsfgfd', 3, '75656756745756', 3, 3),
(10, '17010', 'fdh', 3, 'fghdfgfg', 2, '6746756', 6, 6),
(11, '17010', 'hdfdghgfg', 4, 'fghgd', 2, '67457567', 6, 6),
(12, '17005', 'uiyui', 4, 'yutytuy', 2, '675435665', 6, 8),
(13, '17005', 'uiuiuiui', 4, 'uiyiuyiu', 2, '565789975432', 6, 8),
(14, '17005', 'a', 5, 'a', 2, 'a', 4, 6),
(15, '17005', 'b', 3, 'b', 3, 'b', 9, 6);

-- --------------------------------------------------------

--
-- Table structure for table `hr_job`
--

CREATE TABLE `hr_job` (
  `id` int(10) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `department_id` int(10) NOT NULL,
  `shift_id` int(10) NOT NULL,
  `section_id` int(10) NOT NULL,
  `designation_id` int(10) NOT NULL,
  `joining_date` varchar(16) NOT NULL,
  `released_note` varchar(500) NOT NULL,
  `date` varchar(14) NOT NULL,
  `status` int(2) NOT NULL COMMENT '1=active,0=inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_job`
--

INSERT INTO `hr_job` (`id`, `emp_id`, `department_id`, `shift_id`, `section_id`, `designation_id`, `joining_date`, `released_note`, `date`, `status`) VALUES
(1, '17001', 1, 1, 3, 1, '2017-01-01', '', '', 1),
(2, '17002', 5, 1, 3, 2, '2017-12-01', '', '', 1),
(3, '17003', 4, 1, 3, 1, '2017-12-10', '', '', 1),
(4, '17004', 2, 1, 3, 2, '2017-12-10', '', '', 1),
(5, '17005', 4, 1, 3, 2, '2017-12-26', '', '', 1),
(6, '17006', 4, 1, 3, 3, '2017-12-05', '', '', 1),
(7, '17007', 4, 1, 3, 2, '2017-12-12', '', '', 1),
(8, '17008', 4, 1, 3, 2, '2017-12-11', '', '', 1),
(9, '17009', 2, 1, 4, 1, '2017-12-26', '', '', 1),
(10, '17010', 3, 1, 3, 1, '2017-12-27', '', '', 1),
(11, '17011', 2, 1, 3, 1, '2017-12-12', '', '', 1),
(12, '17012', 2, 1, 4, 1, '2017-12-20', '', '', 1),
(13, '17013', 1, 1, 3, 1, '2017-12-06', '', '', 1),
(14, '17014', 5, 1, 4, 2, '2017-12-13', '', '', 1),
(15, '17015', 4, 1, 3, 2, '2017-12-12', '', '', 1),
(16, '17016', 3, 1, 3, 1, '2017-12-13', '', '', 1),
(17, '17017', 4, 1, 3, 1, '2017-12-12', '', '', 1),
(18, '17018', 4, 1, 3, 3, '2017-12-12', '', '', 1),
(19, '17019', 3, 1, 3, 2, '2017-12-15', '', '', 1),
(20, '17020', 3, 1, 3, 1, '2017-12-12', '', '', 1),
(21, '17021', 3, 1, 3, 2, '2017-12-19', '', '', 1),
(22, '17022', 5, 2, 5, 2, '2018-01-31', '', '', 1),
(23, '10001', 4, 1, 3, 1, '2018-11-05', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hr_job_posting`
--

CREATE TABLE `hr_job_posting` (
  `id` int(10) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `basic_salary` varchar(10) NOT NULL,
  `department_id` int(10) NOT NULL,
  `shift_id` int(10) NOT NULL,
  `section_id` int(10) NOT NULL,
  `designation_id` int(10) NOT NULL,
  `job_type_id` int(10) NOT NULL,
  `post_name` varchar(100) NOT NULL,
  `joining_date` varchar(16) NOT NULL,
  `confirmation_date` varchar(16) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_job_posting`
--

INSERT INTO `hr_job_posting` (`id`, `emp_id`, `basic_salary`, `department_id`, `shift_id`, `section_id`, `designation_id`, `job_type_id`, `post_name`, `joining_date`, `confirmation_date`, `status`) VALUES
(1, '17001', '50000', 4, 1, 3, 1, 0, 'manager', '2017-10-10', '2017-10-10', 0),
(2, '17002', '50000', 4, 1, 3, 2, 0, 'Officer', '2017-12-01', '2017-12-31', 1),
(3, '17003', '20000', 2, 1, 3, 2, 0, 'manager', '2017-12-11', '2017-12-30', 1),
(4, '17004', '40000', 4, 1, 3, 2, 0, 'md', '2017-12-06', '2017-12-27', 1),
(5, '17005', '60000', 4, 1, 3, 2, 0, 'dmd', '2017-12-11', '2017-12-30', 1),
(6, '17006', '70000', 4, 1, 3, 3, 0, 'md', '2017-12-06', '2017-12-28', 1),
(7, '17007', '80000', 5, 1, 3, 2, 0, 'manager', '2017-12-11', '2017-12-29', 1),
(8, '17008', '40000', 4, 1, 3, 3, 0, 'md', '2017-12-11', '2017-12-30', 1),
(9, '17009', '45100', 4, 1, 2, 2, 0, 'DJ', '2017-12-12', '2017-12-31', 1),
(10, '17010', '54020', 5, 2, 5, 2, 0, 'MD', '2017-12-12', '2017-12-30', 1),
(11, '17011', '78000', 4, 2, 5, 2, 0, 'MD', '2017-12-12', '2017-12-29', 1),
(12, '17012', '4500', 3, 1, 4, 2, 0, 'MD', '2017-12-13', '2017-12-27', 1),
(13, '17001', '12500', 5, 1, 2, 2, 0, 'DD', '2017-12-28', '2017-12-29', 0),
(14, '17001', '15000', 4, 2, 5, 1, 0, 'LL', '2017-12-30', '2018-01-02', 1),
(15, '17013', '40000', 1, 2, 5, 1, 0, 'Officer', '2018-01-31', '2018-01-31', 1),
(16, '17014', '25000', 1, 1, 3, 1, 0, 'Officer', '2018-01-31', '2018-01-31', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hr_leave`
--

CREATE TABLE `hr_leave` (
  `id` int(10) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `leave_type_id` int(10) NOT NULL,
  `from_date` varchar(14) NOT NULL,
  `to_date` varchar(14) NOT NULL,
  `duration` varchar(10) NOT NULL,
  `leave_reason` varchar(500) NOT NULL,
  `attachment_file` varchar(100) NOT NULL,
  `employee_id` varchar(50) NOT NULL,
  `status` char(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_leave`
--

INSERT INTO `hr_leave` (`id`, `emp_id`, `leave_type_id`, `from_date`, `to_date`, `duration`, `leave_reason`, `attachment_file`, `employee_id`, `status`) VALUES
(1, '17010', 1, '2018-01-01', '2018-01-03', '3', 'Personal', '', '17005', '0'),
(2, '17004', 2, '2018-01-01', '2018-01-10', '10', 'ff', '31-12-2017_1514739516.docx', '17006', '100'),
(3, '17010', 3, '2018-01-01', '2018-01-04', '4', 'Personal', '', '17005', '0'),
(5, '17004', 3, '2018-01-03', '2018-01-06', '4', 'N/A', '06-01-2018_1515248722.jpg', '17020', '6'),
(6, '17011', 3, '2018-01-09', '2018-01-12', '4', 'Personal', '09-01-2018_1515512476.docx', '17020', '6'),
(7, '17011', 2, '2018-01-15', '2018-01-18', '4', 'Personal', '09-01-2018_1515512507.docx', '17020', '6'),
(8, '17012', 2, '2018-01-10', '2018-01-12', '3', 'gg', '09-01-2018_1515512550.docx', '17020', ''),
(9, '17020', 1, '2018-01-09', '2018-01-30', '22', 'dd', '09-01-2018_1515512573.docx', '17020', ''),
(10, '17012', 2, '2018-01-10', '2018-01-18', '9', 'gg', '09-01-2018_1515512605.docx', '17020', ''),
(11, '17011', 3, '2018-02-03', '2018-02-04', '2', 'gfhfhfghfg', '03-02-2018_1517639255.jpg', '17001', ''),
(12, '17001', 2, '2018-10-10', '2018-10-01', '1', 'gg', '', '222', '');

-- --------------------------------------------------------

--
-- Table structure for table `hr_leave_comment`
--

CREATE TABLE `hr_leave_comment` (
  `id` int(10) NOT NULL,
  `leave_id` int(10) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_leave_comment`
--

INSERT INTO `hr_leave_comment` (`id`, `leave_id`, `user_id`, `comment`, `status`) VALUES
(16, 2, '17001', 'Forward', 1),
(17, 2, '17003', 'Reject', 3),
(18, 2, '17001', 'Yes', 1),
(19, 2, '17003', 'Forward', 1),
(20, 2, '17002', 'reject', 3),
(21, 2, '17003', 'Approve', 2),
(22, 5, '17001', 'Forward comment', 1),
(23, 6, '17001', 'fgdgdf', 1),
(24, 7, '17001', 'fdgfdgfd', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hr_loan`
--

CREATE TABLE `hr_loan` (
  `id` int(10) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `loan_type_id` int(10) NOT NULL,
  `issue_date` varchar(16) NOT NULL,
  `loan_amount` varchar(10) NOT NULL,
  `no_of_installment` int(10) NOT NULL,
  `amount_of_installment` int(10) NOT NULL,
  `deduction_year` varchar(6) NOT NULL,
  `deduction_month` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_loan`
--

INSERT INTO `hr_loan` (`id`, `emp_id`, `loan_type_id`, `issue_date`, `loan_amount`, `no_of_installment`, `amount_of_installment`, `deduction_year`, `deduction_month`) VALUES
(1, '17001', 1, '2018-02-06', '50000', 5, 10000, '2018', '01'),
(2, '17002', 1, '2018-02-06', '80000', 5, 16000, '2018', '02'),
(3, '17003', 2, '2018-02-15', '48500', 6, 8083, '2018', '03');

-- --------------------------------------------------------

--
-- Table structure for table `hr_nominee`
--

CREATE TABLE `hr_nominee` (
  `id` int(10) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `father_name` varchar(100) NOT NULL,
  `mother_name` varchar(100) NOT NULL,
  `spouse_name` varchar(100) NOT NULL,
  `national_id` varchar(60) NOT NULL,
  `passport_number` varchar(60) NOT NULL,
  `present_address` varchar(200) NOT NULL,
  `permanent_address` varchar(200) NOT NULL,
  `percent` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_nominee`
--

INSERT INTO `hr_nominee` (`id`, `emp_id`, `name`, `father_name`, `mother_name`, `spouse_name`, `national_id`, `passport_number`, `present_address`, `permanent_address`, `percent`) VALUES
(1, '17001', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', '100'),
(2, '17001', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', '10'),
(5, '17007', 'K', 'K', 'K', 'K', 'K', 'K', 'KD', 'KD', 'K'),
(6, '17002', 'm', 'm', 'm', 'm', 'm', 'm', 'mD', 'mD', 'm'),
(7, '17002', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A'),
(8, '17001', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', '20'),
(9, '17003', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A', 'A'),
(10, '17004', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W'),
(11, '17005', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W'),
(12, '17006', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q'),
(13, '17010', 'fghgfh', 'fhdfh', 'fghdfhfg', 'dfghdfhfg', '765867567', '76867', 'fgjhfg', 'jhhgh', '10'),
(14, '17009', 'ghj', 'hfg', 'jhfgjh', 'fgjhfghj', '657', '56754756', 'ghgjfg', 'jhhfgjfg', '90');

-- --------------------------------------------------------

--
-- Table structure for table `hr_previous_job_history`
--

CREATE TABLE `hr_previous_job_history` (
  `id` int(10) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `organization_name` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `position` varchar(100) NOT NULL,
  `job_type` varchar(100) NOT NULL,
  `from_date` varchar(20) NOT NULL,
  `to_date` varchar(20) NOT NULL,
  `duration` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_previous_job_history`
--

INSERT INTO `hr_previous_job_history` (`id`, `emp_id`, `organization_name`, `address`, `position`, `job_type`, `from_date`, `to_date`, `duration`) VALUES
(1, '17001', 'f', 'f', 'fghf', 'fdgfdgfd', '2018-01-01', '2018-01-25', '25'),
(2, '17001', 'gdsfg', 'd', 'dsfgdsfgdf', 'f', '2017-01-06', '2018-01-11', '371'),
(3, '17001', 'fh', 'd', 'fgfg', 'f', '2016-01-01', '2018-01-31', '762'),
(4, '17002', 'fhdf', 'fghff', 'hfdhf', 'dghfdg', '2018-01-18', '2018-01-31', '14'),
(5, '17003', 'fghfgh', 'fghfg', 'dfghdfg', 'dfhfg', '2018-01-04', '2018-01-24', '21'),
(6, '17004', 'fghf', 'fdghfdfg', 'ghdfgh', 'fdf', '2018-01-03', '2018-01-24', '22'),
(7, '17005', 'fdgdsfg', 'dfgdsfgdf', 'sdfgsd', 'fgdfsgdf', '2017-01-06', '2018-01-24', '384'),
(8, '17006', 'h', 'fghdfhfg', 'dfhfgh', 'fghd', '2018-02-01', '2018-02-21', '21'),
(9, '17007', 'ghfdhggf', 'fghdfghdf', 'hdf', 'ghdfghdf', '2018-02-16', '2018-02-21', '6'),
(10, '17005', 'test data1', 'jhgjhgjh1', 'test data1', 'test data1', '2018-10-03', '2019-10-31', '394'),
(11, '17005', 'test data', 'iuiyuiyui', 'test data', 'test data', '2018-10-09', '2018-10-31', '23');

-- --------------------------------------------------------

--
-- Table structure for table `hr_reference`
--

CREATE TABLE `hr_reference` (
  `id` int(10) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `organization` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `email` varchar(60) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_reference`
--

INSERT INTO `hr_reference` (`id`, `emp_id`, `name`, `designation`, `organization`, `address`, `email`, `phone`, `mobile`) VALUES
(1, '17001', 'A', 'wwr', 'wer', 'ertwer', 'wert', 'wert', 'werter'),
(2, '17001', 'b', 'S', 'S', 'S', 'S', 'S', 'S'),
(3, '17001', 'b', 'S', 'S', 'S', 'S', 'S', 'S'),
(4, '17002', 'h', 'Q', 'Q', 'Q', 'Q', 'Q', 'Q'),
(5, '17002', 'h', 'W', 'W', 'W', 'W', 'W', 'W'),
(6, '17003', 'h', 'Q', 'Q', 'W', 'W', 'W', 'W'),
(7, '17003', 'h', 'W', 'W', 'W', 'W', 'W', 'W'),
(8, '17003', 'h', 'W', 'W', 'W', 'W', 'W', 'W'),
(9, '17004', '', 'E', 'E', 'E', 'E', 'E', 'E'),
(10, '17005', 'gfhj', 'hfg', 'jhfgjhfg', 'hjfg', 'hz@gmail.com', '6765', '875675678'),
(11, '17006', 'hjkghjgh', 'j', 'gkjkghjk', 'ghjkghjk', 'ghjkghhg', '87978', '6789678'),
(12, '17005', 'u', 'u', 'u', 'u', 'u', 'u', 'u'),
(13, '17005', 't', 't', 't', 't', 't', 't', 't'),
(14, '17005', 'j', 'j', 'j', 'j', 'j', 'j', 'j'),
(15, '17005', 'r', 'r', 'r', 'r', 'r', 'r', 'r'),
(16, '17005', 'y', 'y', 'y', 'y', 'y', 'y', 'y');

-- --------------------------------------------------------

--
-- Table structure for table `hr_research_and_publication`
--

CREATE TABLE `hr_research_and_publication` (
  `id` int(10) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `title_article` varchar(100) NOT NULL,
  `journal_name` varchar(100) NOT NULL,
  `publish_by` varchar(100) NOT NULL,
  `journal_type` varchar(10) NOT NULL,
  `country` varchar(100) NOT NULL,
  `issn_number` varchar(20) NOT NULL,
  `published_date` varchar(14) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_research_and_publication`
--

INSERT INTO `hr_research_and_publication` (`id`, `emp_id`, `title_article`, `journal_name`, `publish_by`, `journal_type`, `country`, `issn_number`, `published_date`) VALUES
(1, '17001', 'gdsfgdfg', 'dfsgdsfgdfs', 'dfsgdsfgdf', '1', 'fdsgfdsgfd', '21456321', '2018-01-31'),
(2, '17001', 'D', 'D', 'D', '0', 'A', 'A', '2018-01-30'),
(3, '17002', 'A', 'A', 'A', '0', 'A', 'A', '2018-01-03'),
(4, '17003', 'f', 'f', 'f', '0', 'f', 'f', '2018-01-10'),
(5, '17003', 'g', 'g', 'g', '0', 'g', 'g', '2018-01-24'),
(6, '17004', 'h', 'h', 'h', 'bangladesh', 'h', 'h', '2018-01-02'),
(7, '17004', 'h', 'h', 'h', 'national', 'h', 'h', '2018-01-09'),
(8, '17005', 'f', 'f', 'f', '0', 'f', 'f', '2018-01-02'),
(9, '17005', 'y', 'y', 'y', 'y', 'y', 'y', '2018-01-18'),
(10, '17006', 'f', 'f', 'f', '0', 'f', 'f', '2018-01-24'),
(11, '17007', 'f', 'f', 'f', '0', 'f', 'f', '2018-01-17'),
(12, '17005', 'j', 'j', 'j', 'j', 'j', 'j', '2018-10-04'),
(13, '17005', 'k', 'k', 'k', 'k', 'k', 'k', '2018-10-17'),
(14, '17005', 'k', 'k', 'k', 'k', 'k', 'k', '2018-10-24');

-- --------------------------------------------------------

--
-- Table structure for table `hr_salary_basic_info`
--

CREATE TABLE `hr_salary_basic_info` (
  `id` int(11) NOT NULL,
  `emp_id` varchar(20) NOT NULL,
  `salary_type_id` int(10) NOT NULL,
  `salary_categoey_id` int(10) NOT NULL,
  `payment_method_id` int(10) NOT NULL,
  `basic` varchar(100) NOT NULL,
  `house_rent` varchar(100) NOT NULL,
  `house_rent_type` int(10) NOT NULL,
  `medical` varchar(100) NOT NULL,
  `medical_type` int(10) NOT NULL,
  `conveyance` varchar(100) NOT NULL,
  `conveyance_type` int(10) NOT NULL,
  `gross_total` varchar(100) NOT NULL,
  `tax` varchar(100) NOT NULL,
  `tax_type` int(10) NOT NULL,
  `extra_duty` varchar(100) NOT NULL,
  `provident_fund` varchar(100) NOT NULL,
  `provident_fund_type` int(10) NOT NULL,
  `charge_allowance` varchar(100) NOT NULL,
  `charge_allowance_type` int(10) NOT NULL,
  `welfare_fund` varchar(100) NOT NULL,
  `welfare_fund_type` int(10) NOT NULL,
  `other` varchar(100) NOT NULL,
  `other_type` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hr_shift_schedule`
--

CREATE TABLE `hr_shift_schedule` (
  `id` int(10) NOT NULL,
  `shift_id` int(10) NOT NULL,
  `in_time` varchar(10) NOT NULL,
  `out_time` varchar(10) NOT NULL,
  `late_time` varchar(10) NOT NULL,
  `early_out` varchar(10) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_shift_schedule`
--

INSERT INTO `hr_shift_schedule` (`id`, `shift_id`, `in_time`, `out_time`, `late_time`, `early_out`, `status`) VALUES
(1, 1, '9:00', '6:00', '9:30', '5:50', 1),
(2, 2, '9:30', '6:00', '10:00', '5:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hr_training`
--

CREATE TABLE `hr_training` (
  `id` int(10) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `training_title` varchar(100) NOT NULL,
  `topics_covered` varchar(200) NOT NULL,
  `institute` varchar(200) NOT NULL,
  `country` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `duration` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_training`
--

INSERT INTO `hr_training` (`id`, `emp_id`, `training_title`, `topics_covered`, `institute`, `country`, `location`, `duration`) VALUES
(1, '17001', 'dfg', 'gdfs', 'dfgds', 'hghg', 'fd', 'ghfgdf'),
(2, '17001', 'ghfg', 'hfghf', 'ghf', 'ghfg', 'hfgh', 'fghfg'),
(3, '17001', 'fhfghfd', 'ghfd', 'ghfdgh', 'fdhfd', 'fdgh', '2'),
(4, '17001', 'dfg', 'gdfs', 'dfgds', 'hghg', 'fd', 'ghfgdf'),
(5, '17002', 'f', 'f', 'f', 'f', 'f', '2'),
(6, '17002', 'f', 'f', 'f', 'f', 'f', '2'),
(7, '17003', 'dfsg', 'dsfg', 'sdfg', 'dsfg', 'dsgfds', '2'),
(8, '17004', 'vbxb', 'cxvbcx', 'vbcxv', 'bxcvbcx', 'vcxvbc', '4'),
(9, '17004', 'xcvb', 'xcvb', 'cxvb', 'xcvbx', 'cvbxcb', '5'),
(10, '17005', 'xcvb', 'cxvb', 'cxvb', 'cxvb', 'xcb', '1'),
(11, '17006', 'cxvbc', 'cvbxc', 'xvbx', 'vbcx', 'vbxcv', '3'),
(12, '17005', 'A', 'A', 'A', 'A', 'A', 'A'),
(13, '17005', 'g', 'g', 'g', 'g', 'g', 'g'),
(14, '17005', 'h', 'h', 'h', 'h', 'h', 'j');

-- --------------------------------------------------------

--
-- Table structure for table `li_admin`
--

CREATE TABLE `li_admin` (
  `id` int(11) NOT NULL,
  `FullName` varchar(100) DEFAULT NULL,
  `AdminEmail` varchar(120) DEFAULT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `li_admin`
--

INSERT INTO `li_admin` (`id`, `FullName`, `AdminEmail`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'Anuj Kumar', 'phpgurukulofficial@gmail.com', 'admin', 'f925916e2754e5e03f75dd58a5733251', '2017-07-16 18:11:42'),
(2, 'mfhfhf', 'suzonice15@gmail.com', 'suzonice', '03afefe401d493b529045b0ccd5f719f', '2018-10-25 09:13:55');

-- --------------------------------------------------------

--
-- Table structure for table `master_academic_exam`
--

CREATE TABLE `master_academic_exam` (
  `id` int(10) NOT NULL,
  `exam_name` varchar(60) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_academic_exam`
--

INSERT INTO `master_academic_exam` (`id`, `exam_name`, `status`) VALUES
(1, 'Mid Term', 1),
(2, 'Pretest', 0),
(3, 'Final', 0);

-- --------------------------------------------------------

--
-- Table structure for table `master_admission_fee`
--

CREATE TABLE `master_admission_fee` (
  `id` int(10) NOT NULL,
  `year` varchar(4) NOT NULL,
  `particulars` varchar(100) NOT NULL,
  `amount` varchar(10) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_admission_fee`
--

INSERT INTO `master_admission_fee` (`id`, `year`, `particulars`, `amount`, `status`) VALUES
(1, '2018', 'Admission Fee', '3000', 0),
(2, '2018', 'Lab Fee', '1000.10', 0),
(3, '2018', 'Extra Curricular Activities Fee', '1000.50', 0),
(4, '2018', 'Library Fee', '1000.30', 1),
(5, '2018', 'Transport Development fee', '2000.40', 1),
(6, '2018', 'Other', '500', 1),
(7, '2018', 'test1', '20009', 1);

-- --------------------------------------------------------

--
-- Table structure for table `master_bank`
--

CREATE TABLE `master_bank` (
  `id` int(10) NOT NULL,
  `bank_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_bank`
--

INSERT INTO `master_bank` (`id`, `bank_name`) VALUES
(1, 'AB Bank'),
(2, 'Islami Bank'),
(3, 'BRACK BANK'),
(4, 'EBL Bank');

-- --------------------------------------------------------

--
-- Table structure for table `master_bank_branch`
--

CREATE TABLE `master_bank_branch` (
  `id` int(10) NOT NULL,
  `bank_id` int(10) NOT NULL,
  `bank_branch_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_bank_branch`
--

INSERT INTO `master_bank_branch` (`id`, `bank_id`, `bank_branch_name`) VALUES
(1, 1, 'Mirpur'),
(3, 2, 'Mirpur');

-- --------------------------------------------------------

--
-- Table structure for table `master_blood_group`
--

CREATE TABLE `master_blood_group` (
  `id` int(10) NOT NULL,
  `blood_group_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_blood_group`
--

INSERT INTO `master_blood_group` (`id`, `blood_group_name`) VALUES
(1, 'O+'),
(2, 'O-'),
(3, 'A+'),
(4, 'A-'),
(5, 'B+'),
(6, 'B-'),
(7, 'AB+'),
(8, 'AB-');

-- --------------------------------------------------------

--
-- Table structure for table `master_board`
--

CREATE TABLE `master_board` (
  `id` int(10) NOT NULL,
  `board_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_board`
--

INSERT INTO `master_board` (`id`, `board_name`) VALUES
(1, 'Dhaka Board'),
(2, 'Rajshahi Board'),
(3, 'Comilla Board'),
(4, 'Jessore Board'),
(5, 'Chittagong Board'),
(6, 'Barisal Board'),
(7, 'Sylhet Board'),
(8, 'Dinajpur Board'),
(9, 'Madrasah Board'),
(10, 'Technical Board');

-- --------------------------------------------------------

--
-- Table structure for table `master_bonus`
--

CREATE TABLE `master_bonus` (
  `id` int(10) NOT NULL,
  `bonus_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_bonus`
--

INSERT INTO `master_bonus` (`id`, `bonus_name`) VALUES
(1, 'Eid Festival');

-- --------------------------------------------------------

--
-- Table structure for table `master_class`
--

CREATE TABLE `master_class` (
  `id` int(10) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_class`
--

INSERT INTO `master_class` (`id`, `name`) VALUES
(1, 'One'),
(2, 'Two'),
(3, 'Three'),
(4, 'Four'),
(5, 'Five'),
(6, 'Six'),
(7, 'Seven'),
(8, 'Eigth'),
(9, 'Nine'),
(10, 'Ten'),
(11, 'Eleven'),
(12, 'Twelve');

-- --------------------------------------------------------

--
-- Table structure for table `master_class_subject`
--

CREATE TABLE `master_class_subject` (
  `id` int(10) NOT NULL,
  `class_id` int(4) NOT NULL,
  `subject_id` int(4) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_class_subject`
--

INSERT INTO `master_class_subject` (`id`, `class_id`, `subject_id`, `status`) VALUES
(1, 1, 1, 1),
(2, 1, 2, 1),
(3, 5, 2, 1),
(4, 4, 2, 1),
(5, 5, 2, 1),
(6, 5, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `master_department`
--

CREATE TABLE `master_department` (
  `id` int(10) NOT NULL,
  `department_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_department`
--

INSERT INTO `master_department` (`id`, `department_name`) VALUES
(1, 'Audit'),
(2, 'Chief Engineer'),
(3, 'HR'),
(4, 'Accounting'),
(5, 'ICT');

-- --------------------------------------------------------

--
-- Table structure for table `master_designation`
--

CREATE TABLE `master_designation` (
  `id` int(10) NOT NULL,
  `designation_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_designation`
--

INSERT INTO `master_designation` (`id`, `designation_name`) VALUES
(1, 'Accounts officer'),
(2, 'System Analyst'),
(3, 'MD');

-- --------------------------------------------------------

--
-- Table structure for table `master_district`
--

CREATE TABLE `master_district` (
  `id` int(10) NOT NULL,
  `division_id` int(10) NOT NULL,
  `district_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_district`
--

INSERT INTO `master_district` (`id`, `division_id`, `district_name`) VALUES
(1, 3, 'Faridpur'),
(2, 3, 'Dhaka'),
(3, 3, 'Gazipur'),
(4, 3, 'Gopalganj'),
(5, 3, 'Jamalpur'),
(6, 3, 'Kishoreganj'),
(7, 3, 'Madaripur'),
(8, 3, 'Manikganj'),
(9, 3, 'Munshiganj'),
(10, 3, 'Mymensingh'),
(11, 3, 'Narayanganj'),
(12, 3, 'Norshingdi'),
(13, 3, 'Netrokona'),
(14, 3, 'Rajbari'),
(15, 3, 'Shariatpur'),
(16, 3, 'Sherpur'),
(17, 3, 'Tangail'),
(18, 2, 'Bagerhat'),
(19, 2, 'Chuadanga'),
(20, 2, 'Jessore'),
(21, 2, 'Jhenaidah'),
(22, 2, 'Khulna'),
(23, 2, 'Kushtia'),
(24, 2, 'Magura'),
(25, 2, 'Meherpur'),
(26, 2, 'Narail'),
(27, 2, 'Satkhira');

-- --------------------------------------------------------

--
-- Table structure for table `master_division`
--

CREATE TABLE `master_division` (
  `id` int(10) NOT NULL,
  `division_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_division`
--

INSERT INTO `master_division` (`id`, `division_name`) VALUES
(1, 'Rajshahi '),
(2, 'Khulna'),
(3, 'Dhaka'),
(4, 'Sylhet'),
(5, 'Barisal '),
(6, 'Chittagong'),
(7, 'Rangpur '),
(8, 'Natore');

-- --------------------------------------------------------

--
-- Table structure for table `master_exam_degree`
--

CREATE TABLE `master_exam_degree` (
  `id` int(10) NOT NULL,
  `degree_name` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_exam_degree`
--

INSERT INTO `master_exam_degree` (`id`, `degree_name`) VALUES
(1, 'A+'),
(2, 'A'),
(3, 'A-'),
(4, 'B+'),
(5, 'B'),
(6, 'B-'),
(7, 'C+'),
(8, 'C'),
(9, 'C-');

-- --------------------------------------------------------

--
-- Table structure for table `master_exam_fee`
--

CREATE TABLE `master_exam_fee` (
  `id` int(10) NOT NULL,
  `year` varchar(4) NOT NULL,
  `particulars` varchar(200) NOT NULL,
  `amount` int(10) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_exam_fee`
--

INSERT INTO `master_exam_fee` (`id`, `year`, `particulars`, `amount`, `status`) VALUES
(1, '2018', 'test data', 2000, 0),
(2, '2018', 'test data2', 2000, 1),
(3, '2018', 'test data1', 2000, 1),
(4, '2018', 'Late fee', 380, 1);

-- --------------------------------------------------------

--
-- Table structure for table `master_exam_name`
--

CREATE TABLE `master_exam_name` (
  `id` int(10) NOT NULL,
  `exam_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_exam_name`
--

INSERT INTO `master_exam_name` (`id`, `exam_name`) VALUES
(1, 'S.S.C'),
(2, 'H.S.C');

-- --------------------------------------------------------

--
-- Table structure for table `master_freedom_fighter_relation`
--

CREATE TABLE `master_freedom_fighter_relation` (
  `id` int(10) NOT NULL,
  `relation_name` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_freedom_fighter_relation`
--

INSERT INTO `master_freedom_fighter_relation` (`id`, `relation_name`) VALUES
(1, 'Son'),
(2, 'Doughter');

-- --------------------------------------------------------

--
-- Table structure for table `master_gender`
--

CREATE TABLE `master_gender` (
  `id` int(10) NOT NULL,
  `gender_name` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_gender`
--

INSERT INTO `master_gender` (`id`, `gender_name`) VALUES
(1, 'Male'),
(2, 'Female'),
(3, 'Other');

-- --------------------------------------------------------

--
-- Table structure for table `master_holiday`
--

CREATE TABLE `master_holiday` (
  `id` int(10) NOT NULL,
  `holiday_name` varchar(100) NOT NULL,
  `start_date` varchar(12) NOT NULL,
  `end_date` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_holiday`
--

INSERT INTO `master_holiday` (`id`, `holiday_name`, `start_date`, `end_date`) VALUES
(1, 'Sheikh Mujibur Rahman’s birthday', '2017-01-10', '2017-01-10'),
(2, 'Language Martyrs\' Day', '2017-01-10', '2017-01-10'),
(3, 'Independence Day', '2017-20-20', '2017-20-20');

-- --------------------------------------------------------

--
-- Table structure for table `master_job_type`
--

CREATE TABLE `master_job_type` (
  `id` int(10) NOT NULL,
  `job_type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_job_type`
--

INSERT INTO `master_job_type` (`id`, `job_type`) VALUES
(1, 'Daily Basis'),
(2, 'Permanent'),
(3, 'Contractual'),
(4, 'Deputed');

-- --------------------------------------------------------

--
-- Table structure for table `master_leave_type`
--

CREATE TABLE `master_leave_type` (
  `id` int(10) NOT NULL,
  `leave_name` varchar(30) NOT NULL,
  `duration` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_leave_type`
--

INSERT INTO `master_leave_type` (`id`, `leave_name`, `duration`) VALUES
(1, 'Maternity Leave', '20'),
(2, 'Casual Leave', '10'),
(3, 'Earned Leave', '23');

-- --------------------------------------------------------

--
-- Table structure for table `master_loan_type`
--

CREATE TABLE `master_loan_type` (
  `id` int(10) NOT NULL,
  `loan_type_name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_loan_type`
--

INSERT INTO `master_loan_type` (`id`, `loan_type_name`) VALUES
(1, 'Salary Loan'),
(2, 'GPF Loan');

-- --------------------------------------------------------

--
-- Table structure for table `master_marital_status`
--

CREATE TABLE `master_marital_status` (
  `id` int(10) NOT NULL,
  `marital_status_name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_marital_status`
--

INSERT INTO `master_marital_status` (`id`, `marital_status_name`) VALUES
(1, 'Married'),
(2, 'Unmarried'),
(3, 'Separated'),
(4, 'Single'),
(5, 'Widowed');

-- --------------------------------------------------------

--
-- Table structure for table `master_menu`
--

CREATE TABLE `master_menu` (
  `id` int(10) NOT NULL,
  `module_id` int(10) NOT NULL,
  `menu_name` varchar(100) NOT NULL,
  `menu_url` varchar(100) NOT NULL,
  `menu_icon` varchar(100) NOT NULL,
  `menu_sort` int(3) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_menu`
--

INSERT INTO `master_menu` (`id`, `module_id`, `menu_name`, `menu_url`, `menu_icon`, `menu_sort`, `status`) VALUES
(1, 1, 'User Configuration', 'javascript:;', 'fa fa-share', 1, 1),
(2, 1, 'Master Configuration', 'javascript:;', 'fa fa-share', 2, 1),
(3, 2, 'Employee Info', 'javascript:;', 'fa fa-share', 1, 1),
(4, 2, 'Attendance', 'javascript:;', 'fa fa-share', 2, 1),
(5, 2, 'Leave Management', 'javascript:;', 'fa fa-share', 3, 1),
(6, 2, 'Roster', 'javascript:;', 'fa fa-share', 4, 1),
(7, 2, 'Loan', 'javascript:;', 'fa fa-share', 5, 1),
(8, 2, 'Salary', 'javascript:;	', 'fa fa-share', 7, 1),
(9, 2, 'Bonous', 'javascript:;	', 'fa fa-share', 6, 1),
(10, 3, 'Student Info', 'javascript:;', 'fa fa-share', 1, 1),
(11, 3, 'Report', 'javascript:;', 'fa fa-share', 2, 1),
(13, 4, 'Teacher', 'javascript:;', 'fa fa-share', 1, 1),
(14, 4, 'Student', 'javascript:;', 'fa fa-share', 2, 1),
(15, 4, 'Routine', 'javascript:;', 'fa fa-share', 3, 1),
(16, 4, 'Report', 'javascript:;', 'fa fa-share', 4, 1),
(17, 5, 'Result', 'javascript:;', 'fa fa-share', 1, 1),
(18, 5, 'Routine', 'javascript:;', 'fa fa-share', 2, 1),
(19, 5, 'Seat Plan', 'javascript:;', 'fa fa-share', 3, 1),
(20, 5, 'Admit Card', 'javascript:;', 'fa fa-share', 4, 1),
(21, 6, 'Student', 'javascript:;', 'fa fa-share', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `master_module`
--

CREATE TABLE `master_module` (
  `id` int(10) NOT NULL,
  `module_name` varchar(50) NOT NULL,
  `module_url` varchar(100) NOT NULL,
  `module_icon` varchar(100) NOT NULL,
  `sort` int(3) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_module`
--

INSERT INTO `master_module` (`id`, `module_name`, `module_url`, `module_icon`, `sort`, `status`) VALUES
(1, 'Configuration', 'javacsript:;', 'fa fa-fw fa-sitemap', 1, 1),
(2, 'HR', 'javacsript:;', 'fa fa-fw fa-sitemap', 2, 1),
(3, 'Admission', 'javacsript:;', 'fa fa-fw fa-sitemap', 3, 1),
(4, 'Academic', 'javascript:;', 'fa fa-fw fa-sitemap', 4, 1),
(5, 'Exam', 'javascript:;', 'fa fa-fw fa-sitemap', 5, 1),
(6, 'Account', 'javascript:;', 'fa fa-fw fa-sitemap', 6, 1),
(7, 'book', 'javascript:;', 'fa fa-fw fa-sitemap', 7, 1);

-- --------------------------------------------------------

--
-- Table structure for table `master_profession`
--

CREATE TABLE `master_profession` (
  `id` int(10) NOT NULL,
  `profession_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_profession`
--

INSERT INTO `master_profession` (`id`, `profession_name`) VALUES
(1, 'Student'),
(2, 'Private Service'),
(3, 'Government Service'),
(4, 'Housewife'),
(5, 'Other');

-- --------------------------------------------------------

--
-- Table structure for table `master_religion`
--

CREATE TABLE `master_religion` (
  `id` int(10) NOT NULL,
  `religion_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_religion`
--

INSERT INTO `master_religion` (`id`, `religion_name`) VALUES
(1, 'Muslim'),
(2, 'Hindu'),
(3, 'Christian'),
(4, 'Buddist');

-- --------------------------------------------------------

--
-- Table structure for table `master_role`
--

CREATE TABLE `master_role` (
  `id` int(10) NOT NULL,
  `role_name` varchar(100) NOT NULL,
  `status` int(2) NOT NULL,
  `leave_status` int(2) NOT NULL,
  `loan_status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_role`
--

INSERT INTO `master_role` (`id`, `role_name`, `status`, `leave_status`, `loan_status`) VALUES
(1, 'Admin', 1, 0, 0),
(2, 'Superadmin', 1, 0, 0),
(3, 'Department Head', 1, 0, 0),
(5, 'MD', 1, 1, 0),
(6, 'GM', 1, 1, 0),
(7, 'User', 1, 0, 0),
(8, 'Student', 1, 0, 0),
(9, 'Teacher', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `master_section`
--

CREATE TABLE `master_section` (
  `id` int(10) NOT NULL,
  `shift_id` int(10) NOT NULL,
  `section_name` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_section`
--

INSERT INTO `master_section` (`id`, `shift_id`, `section_name`) VALUES
(1, 1, 'D'),
(2, 1, 'C'),
(3, 1, 'A'),
(4, 1, 'B'),
(5, 2, 'A'),
(6, 2, 'B');

-- --------------------------------------------------------

--
-- Table structure for table `master_shift`
--

CREATE TABLE `master_shift` (
  `id` int(10) NOT NULL,
  `shift_name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_shift`
--

INSERT INTO `master_shift` (`id`, `shift_name`) VALUES
(1, 'Day'),
(2, 'Evening');

-- --------------------------------------------------------

--
-- Table structure for table `master_study_group`
--

CREATE TABLE `master_study_group` (
  `id` int(10) NOT NULL,
  `group_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_study_group`
--

INSERT INTO `master_study_group` (`id`, `group_name`) VALUES
(1, 'Science'),
(2, 'Arth'),
(3, 'Commerce'),
(4, 'Common');

-- --------------------------------------------------------

--
-- Table structure for table `master_subject`
--

CREATE TABLE `master_subject` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `status` int(11) NOT NULL COMMENT '1=general,2=fourth subject'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_subject`
--

INSERT INTO `master_subject` (`id`, `name`, `status`) VALUES
(1, 'Bangla', 1),
(2, 'Math', 2);

-- --------------------------------------------------------

--
-- Table structure for table `master_sub_menu`
--

CREATE TABLE `master_sub_menu` (
  `id` int(10) NOT NULL,
  `module_id` int(10) NOT NULL,
  `menu_id` int(10) NOT NULL,
  `sub_menu_name` varchar(100) NOT NULL,
  `sub_menu_url` varchar(100) NOT NULL,
  `sub_menu_icon` varchar(100) NOT NULL,
  `sub_menu_sort` int(3) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_sub_menu`
--

INSERT INTO `master_sub_menu` (`id`, `module_id`, `menu_id`, `sub_menu_name`, `sub_menu_url`, `sub_menu_icon`, `sub_menu_sort`, `status`) VALUES
(1, 1, 2, 'Module', 'master/module/all_module', 'fa fa-files-o', 1, 1),
(2, 1, 2, 'Menu', 'master/menu/all_menu', 'fa fa-files-o', 2, 1),
(3, 1, 2, 'Sub-Menu', 'master/sub_menu/all_sub_menu', 'fa fa-files-o', 3, 1),
(4, 1, 1, 'User Role', 'master/user/all_role', 'fa fa-files-o', 1, 1),
(5, 1, 1, 'Create user', 'master/user/all_user', 'fa fa-files-o', 2, 1),
(6, 1, 1, 'User Privilege', 'master/user/all_privilege', 'fa fa-files-o', 3, 1),
(7, 1, 2, 'Division', 'master/division/all_division', 'fa fa-files-o', 4, 1),
(8, 1, 2, 'District', 'master/district/all_district', 'fa fa-files-o', 5, 1),
(9, 1, 2, 'Thana', 'master/thana/all_thana', 'fa fa-files-o', 6, 1),
(10, 1, 2, 'Bank', 'master/bank/all_bank', 'fa fa-files-o', 7, 1),
(11, 1, 2, 'Bank Branch', 'master/bank_branch/all_bank_branch', 'fa fa-files-o', 8, 1),
(12, 1, 2, 'Department', 'master/department/all_department', 'fa fa-files-o', 9, 1),
(13, 1, 2, 'Designation', 'master/designation/all_designation', 'fa fa-files-o', 10, 1),
(15, 1, 2, 'Weekend', 'master/weekend/all_weekend', 'fa fa-files-o', 11, 1),
(16, 1, 2, 'Section', 'master/section/all_section', 'fa fa-files-o', 12, 1),
(17, 1, 2, 'Leave Type', 'master/leave_type/all_leave_type', 'fa fa-files-o', 13, 1),
(18, 1, 2, 'Holiday', 'master/holiday/all_holiday', 'fa fa-files-o', 14, 1),
(19, 2, 3, 'Basic', 'hr/basic/all_basic', 'fa fa-files-o', 3, 1),
(20, 2, 4, 'Monthly Report', 'hr/attendance_report/all_monthly_report', ' fa fa-files-o', 2, 1),
(21, 2, 3, 'Family', 'hr/family/all_family', 'fa fa-files-o', 4, 1),
(22, 2, 3, 'Job', 'hr/job/all_job', 'fa fa-files-o', 1, 1),
(23, 2, 3, 'Job Posting', 'hr/job_posting/all_job_posting', 'fa fa-files-o', 2, 1),
(24, 2, 3, 'Child', 'hr/child/all_child', 'fa fa-files-o', 5, 1),
(25, 2, 3, 'Academic', 'hr/academic/all_academic', 'fa fa-files-o', 6, 1),
(26, 2, 4, 'Attendance', 'hr/attendance/all_attendance', 'fa fa-files-o', 1, 1),
(27, 2, 5, 'Leave Application', 'hr/leave/all_leave', 'fa fa-files-o', 1, 1),
(28, 2, 3, 'Assigning Dept Head', 'hr/department_head/all_department_head', 'fa fa-files-o', 7, 1),
(29, 2, 6, 'Assigning Weekend', 'hr/weekend/all_weekend', 'fa fa-files-o', 1, 1),
(30, 2, 6, 'Assigning Roster ', 'hr/roster/all_roster', 'fa fa-files-o', 2, 1),
(31, 2, 6, 'Shift Schedule', 'hr/shift_schedule/all_shift_schedule', 'fa fa-files-o', 3, 1),
(32, 2, 3, 'Ward and Honour', 'hr/ward_and_honours/all_ward_and_honours', 'fa fa-files-o', 8, 1),
(33, 2, 3, 'Contact', 'hr/contact/all_contact', 'fa fa-files-o', 9, 1),
(34, 2, 3, 'Co-curricular activities', 'hr/co_curricular_activities/all_co_curricular_activities', 'fa fa-files-o', 10, 1),
(35, 2, 3, 'Experience', 'hr/experience/all_experience', 'fa fa-files-o', 11, 1),
(36, 2, 3, 'Nominee', 'hr/nominee/all_nominee', 'fa fa-files-o', 12, 1),
(37, 2, 3, 'Previous Job History', 'hr/previous_job_history/all_previous_job_history', 'fa fa-files-o', 13, 1),
(38, 2, 3, 'Reference', 'hr/reference/all_reference', 'fa fa-files-o', 14, 1),
(39, 2, 3, 'Research and Publication', 'hr/research_and_publication/all_research_and_publication', 'fa fa-files-o', 15, 1),
(40, 2, 3, 'Training', 'hr/training/all_training', 'fa fa-files-o', 16, 1),
(41, 2, 3, 'Resume', 'hr/resume/all_resume', 'fa fa-files-o', 17, 1),
(42, 2, 3, 'My Resume', 'hr/my_resume/all_my_resume', 'fa fa-files-o', 18, 1),
(43, 2, 7, 'Add Loan', 'hr/loan/all_loan', 'fa fa-files-o', 1, 1),
(44, 2, 8, 'Additional&Deduction', 'hr/additional_and_deduction/all_additional_and_deduction', 'fa fa-files-o', 1, 1),
(45, 2, 9, 'Add Bonus', 'hr/bonus/all_bonus', 'fa fa-files-o', 1, 1),
(46, 2, 8, 'Salary Entry', 'hr/salary_entry/all_salary_entry', 'fa fa-files-o', 2, 1),
(47, 2, 8, 'Create Salary', 'hr/create_salary/all_create_salary', 'fa fa-files-o', 3, 1),
(50, 3, 11, 'All Report', 'admission/admission_report/all_admission_report', 'fa fa-files-o', 1, 1),
(51, 3, 10, 'Student List', 'admission/student_info/all_student', 'fa fa-files-o', 1, 1),
(52, 4, 13, 'All Teacher', 'academic/teacher/all_teacher', 'fa fa-files-o', 1, 1),
(53, 4, 14, 'All Student', 'academic/student/all_student', 'fa fa-files-o', 1, 1),
(54, 4, 15, 'Class Routuine', 'academic/routine/all_routine', 'fa fa-files-o', 1, 1),
(55, 4, 16, 'Combined Report', 'academic/report/all_report', 'fa fa-files-o', 1, 1),
(56, 5, 17, 'Grade Sheet', 'exam/result/all_result', 'fa fa-files-o', 1, 1),
(57, 5, 18, 'Exam Routine', 'exam/routine/all_routine', 'fa fa-files-o', 2, 1),
(58, 5, 19, 'Create Sheet Plan', 'exam/seat_plan/all_seat_plan', 'fa fa-files-o', 1, 1),
(59, 5, 20, 'Create Admit Card', 'exam/admit_card/all_admit_card', 'fa fa-files-o', 1, 1),
(60, 6, 21, 'Admission Fee', 'account/admission_fee/all_admission_fee', 'fa fa-files-o', 1, 1),
(61, 1, 2, 'Admission Fee', 'master/admission_fee/all_admission_fee', 'fa fa-files-o', 15, 1),
(62, 4, 14, 'Enroll Class', 'academic/enroll_class/all_enroll_class', 'fa fa-files-o', 2, 1),
(63, 1, 2, 'Class Subject', 'master/class_subject/all_class_subject', 'fa fa-files-o', 16, 1),
(64, 4, 14, 'Student Fourth Subject', 'academic/fourth_subject/all_fourth_subject', 'fa fa-files-o', 3, 1),
(65, 6, 21, 'Exam Fee', 'account/exam_fee/all_exam_fee', 'fa fa-files-o', 2, 1),
(66, 1, 2, 'Exam Fee', 'master/exam_fee/all_exam_fee', 'fa fa-files-o', 17, 1);

-- --------------------------------------------------------

--
-- Table structure for table `master_thana`
--

CREATE TABLE `master_thana` (
  `id` int(10) NOT NULL,
  `division_id` int(10) NOT NULL,
  `district_id` int(10) NOT NULL,
  `thana_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_thana`
--

INSERT INTO `master_thana` (`id`, `division_id`, `district_id`, `thana_name`) VALUES
(2, 3, 2, 'Dohar'),
(3, 3, 2, 'Dhamrai'),
(4, 3, 2, 'Keraniganj'),
(5, 3, 2, 'Savar'),
(6, 3, 2, 'Nawabganj');

-- --------------------------------------------------------

--
-- Table structure for table `master_user`
--

CREATE TABLE `master_user` (
  `id` int(10) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role_id` int(10) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_user`
--

INSERT INTO `master_user` (`id`, `user_name`, `password`, `role_id`, `status`) VALUES
(1, 'admin', '123456', 1, 1),
(2, 'superadmin', '123456', 2, 1),
(3, '17001', '123456', 3, 1),
(4, '17002', '123456', 5, 1),
(5, '17003', '123456', 6, 1),
(6, '17004', '123456', 7, 1),
(7, '17010', '123456', 7, 1),
(8, '17011', '123456', 7, 1),
(9, '17012', '123456', 7, 1),
(10, '17014', '123456', 7, 1),
(11, '180001', '123456', 8, 1),
(12, '17005', '123456', 9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `master_weekend`
--

CREATE TABLE `master_weekend` (
  `id` int(10) NOT NULL,
  `weekend_name` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_weekend`
--

INSERT INTO `master_weekend` (`id`, `weekend_name`) VALUES
(1, 'Saturday'),
(2, 'Sunday'),
(3, 'Monday'),
(4, 'Tuesday'),
(5, 'Wednesday'),
(6, 'Thursday'),
(7, 'Friday');

-- --------------------------------------------------------

--
-- Table structure for table `master_year`
--

CREATE TABLE `master_year` (
  `id` int(10) NOT NULL,
  `year_name` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_year`
--

INSERT INTO `master_year` (`id`, `year_name`) VALUES
(1, '2017'),
(2, '2018'),
(3, '2019'),
(4, '2020'),
(5, '2021'),
(6, '2022');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `skill` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `skill`) VALUES
(3, 'Mamun', 'manun@gmail.com', 'C++'),
(12, 'shahinul islam suzon', 'suzonice10@gamil.com', 'ffffff'),
(13, 'milon', ' mitul@gmail.com', 'php');

-- --------------------------------------------------------

--
-- Table structure for table `user_role_permission`
--

CREATE TABLE `user_role_permission` (
  `id` int(10) NOT NULL,
  `module_id` int(10) NOT NULL,
  `menu_id` int(10) NOT NULL,
  `sub_menu_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_role_permission`
--

INSERT INTO `user_role_permission` (`id`, `module_id`, `menu_id`, `sub_menu_id`, `user_id`, `status`) VALUES
(510, 2, 5, 27, 3, 1),
(511, 2, 5, 27, 6, 1),
(513, 2, 5, 27, 5, 1),
(981, 2, 3, 42, 7, 1),
(982, 2, 5, 27, 7, 1),
(1622, 3, 10, 48, 8, 1),
(1623, 3, 10, 51, 8, 1),
(1995, 6, 21, 60, 1, 1),
(1996, 6, 21, 65, 1, 1),
(1997, 5, 17, 56, 1, 1),
(1998, 5, 18, 57, 1, 1),
(1999, 5, 19, 58, 1, 1),
(2000, 5, 20, 59, 1, 1),
(2001, 4, 13, 52, 1, 1),
(2002, 4, 14, 53, 1, 1),
(2003, 4, 14, 62, 1, 1),
(2004, 4, 14, 64, 1, 1),
(2005, 4, 15, 54, 1, 1),
(2006, 4, 16, 55, 1, 1),
(2007, 3, 10, 48, 1, 1),
(2008, 3, 10, 51, 1, 1),
(2009, 3, 11, 50, 1, 1),
(2010, 3, 12, 49, 1, 1),
(2011, 2, 3, 19, 1, 1),
(2012, 2, 3, 21, 1, 1),
(2013, 2, 3, 22, 1, 1),
(2014, 2, 3, 23, 1, 1),
(2015, 2, 3, 24, 1, 1),
(2016, 2, 3, 25, 1, 1),
(2017, 2, 3, 28, 1, 1),
(2018, 2, 3, 32, 1, 1),
(2019, 2, 3, 33, 1, 1),
(2020, 2, 3, 34, 1, 1),
(2021, 2, 3, 35, 1, 1),
(2022, 2, 3, 36, 1, 1),
(2023, 2, 3, 37, 1, 1),
(2024, 2, 3, 38, 1, 1),
(2025, 2, 3, 39, 1, 1),
(2026, 2, 3, 40, 1, 1),
(2027, 2, 3, 41, 1, 1),
(2028, 2, 4, 20, 1, 1),
(2029, 2, 4, 26, 1, 1),
(2030, 2, 5, 27, 1, 1),
(2031, 2, 6, 29, 1, 1),
(2032, 2, 6, 30, 1, 1),
(2033, 2, 6, 31, 1, 1),
(2034, 2, 7, 43, 1, 1),
(2035, 2, 8, 44, 1, 1),
(2036, 2, 8, 46, 1, 1),
(2037, 2, 8, 47, 1, 1),
(2038, 2, 9, 45, 1, 1),
(2039, 1, 1, 4, 1, 1),
(2040, 1, 1, 5, 1, 1),
(2041, 1, 1, 6, 1, 1),
(2042, 1, 2, 1, 1, 1),
(2043, 1, 2, 2, 1, 1),
(2044, 1, 2, 3, 1, 1),
(2045, 1, 2, 7, 1, 1),
(2046, 1, 2, 8, 1, 1),
(2047, 1, 2, 9, 1, 1),
(2048, 1, 2, 10, 1, 1),
(2049, 1, 2, 11, 1, 1),
(2050, 1, 2, 12, 1, 1),
(2051, 1, 2, 13, 1, 1),
(2052, 1, 2, 15, 1, 1),
(2053, 1, 2, 16, 1, 1),
(2054, 1, 2, 17, 1, 1),
(2055, 1, 2, 18, 1, 1),
(2056, 1, 2, 61, 1, 1),
(2057, 1, 2, 63, 1, 1),
(2058, 1, 2, 66, 1, 1),
(2059, 5, 17, 56, 9, 1),
(2060, 4, 14, 62, 9, 1),
(2061, 2, 3, 42, 9, 1),
(2062, 2, 4, 20, 9, 1),
(2063, 2, 4, 26, 9, 1),
(2064, 2, 5, 27, 9, 1),
(2065, 2, 7, 43, 9, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academic_class_teacher`
--
ALTER TABLE `academic_class_teacher`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `academic_enroll_class`
--
ALTER TABLE `academic_enroll_class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `academic_fourth_subject`
--
ALTER TABLE `academic_fourth_subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `academic_studentinfo`
--
ALTER TABLE `academic_studentinfo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_id` (`student_id`);

--
-- Indexes for table `academic_subject_teacher`
--
ALTER TABLE `academic_subject_teacher`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `account_admission_fee`
--
ALTER TABLE `account_admission_fee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `account_exam_fee`
--
ALTER TABLE `account_exam_fee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam_result`
--
ALTER TABLE `exam_result`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_id` (`student_id`,`class_id`,`subject_id`,`shift_id`,`section_id`,`academic_exam_id`,`study_group_id`,`year`);

--
-- Indexes for table `hr_academic`
--
ALTER TABLE `hr_academic`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_additional_and_deduction`
--
ALTER TABLE `hr_additional_and_deduction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_assigning_dept_head`
--
ALTER TABLE `hr_assigning_dept_head`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_assigning_roster`
--
ALTER TABLE `hr_assigning_roster`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_assigning_weekend`
--
ALTER TABLE `hr_assigning_weekend`
  ADD PRIMARY KEY (`emp_id`,`from_date`,`to_date`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `hr_attendance`
--
ALTER TABLE `hr_attendance`
  ADD PRIMARY KEY (`emp_id`,`present_date`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `hr_award_and_honors`
--
ALTER TABLE `hr_award_and_honors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_basic`
--
ALTER TABLE `hr_basic`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email_address` (`email_address`),
  ADD UNIQUE KEY `emp_id` (`emp_id`);

--
-- Indexes for table `hr_bonus`
--
ALTER TABLE `hr_bonus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_child`
--
ALTER TABLE `hr_child`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_contact`
--
ALTER TABLE `hr_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_co_curricular_activities`
--
ALTER TABLE `hr_co_curricular_activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_create_salary`
--
ALTER TABLE `hr_create_salary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_experience`
--
ALTER TABLE `hr_experience`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_family`
--
ALTER TABLE `hr_family`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_job`
--
ALTER TABLE `hr_job`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `emp_id` (`emp_id`);

--
-- Indexes for table `hr_job_posting`
--
ALTER TABLE `hr_job_posting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_leave`
--
ALTER TABLE `hr_leave`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_leave_comment`
--
ALTER TABLE `hr_leave_comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_loan`
--
ALTER TABLE `hr_loan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_nominee`
--
ALTER TABLE `hr_nominee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_previous_job_history`
--
ALTER TABLE `hr_previous_job_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_reference`
--
ALTER TABLE `hr_reference`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_research_and_publication`
--
ALTER TABLE `hr_research_and_publication`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_salary_basic_info`
--
ALTER TABLE `hr_salary_basic_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `emp_id` (`emp_id`);

--
-- Indexes for table `hr_shift_schedule`
--
ALTER TABLE `hr_shift_schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_training`
--
ALTER TABLE `hr_training`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `li_admin`
--
ALTER TABLE `li_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_academic_exam`
--
ALTER TABLE `master_academic_exam`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_admission_fee`
--
ALTER TABLE `master_admission_fee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_bank`
--
ALTER TABLE `master_bank`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_bank_branch`
--
ALTER TABLE `master_bank_branch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_blood_group`
--
ALTER TABLE `master_blood_group`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_board`
--
ALTER TABLE `master_board`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_bonus`
--
ALTER TABLE `master_bonus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_class`
--
ALTER TABLE `master_class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_class_subject`
--
ALTER TABLE `master_class_subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_department`
--
ALTER TABLE `master_department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_designation`
--
ALTER TABLE `master_designation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_district`
--
ALTER TABLE `master_district`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_division`
--
ALTER TABLE `master_division`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_exam_degree`
--
ALTER TABLE `master_exam_degree`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_exam_fee`
--
ALTER TABLE `master_exam_fee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_exam_name`
--
ALTER TABLE `master_exam_name`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_freedom_fighter_relation`
--
ALTER TABLE `master_freedom_fighter_relation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_gender`
--
ALTER TABLE `master_gender`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_holiday`
--
ALTER TABLE `master_holiday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_job_type`
--
ALTER TABLE `master_job_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_leave_type`
--
ALTER TABLE `master_leave_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_loan_type`
--
ALTER TABLE `master_loan_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_marital_status`
--
ALTER TABLE `master_marital_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_menu`
--
ALTER TABLE `master_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_module`
--
ALTER TABLE `master_module`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_profession`
--
ALTER TABLE `master_profession`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_religion`
--
ALTER TABLE `master_religion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_role`
--
ALTER TABLE `master_role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_section`
--
ALTER TABLE `master_section`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_shift`
--
ALTER TABLE `master_shift`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_study_group`
--
ALTER TABLE `master_study_group`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_subject`
--
ALTER TABLE `master_subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_sub_menu`
--
ALTER TABLE `master_sub_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_thana`
--
ALTER TABLE `master_thana`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_user`
--
ALTER TABLE `master_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_weekend`
--
ALTER TABLE `master_weekend`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `master_year`
--
ALTER TABLE `master_year`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_role_permission`
--
ALTER TABLE `user_role_permission`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academic_class_teacher`
--
ALTER TABLE `academic_class_teacher`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `academic_enroll_class`
--
ALTER TABLE `academic_enroll_class`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `academic_fourth_subject`
--
ALTER TABLE `academic_fourth_subject`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `academic_studentinfo`
--
ALTER TABLE `academic_studentinfo`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `academic_subject_teacher`
--
ALTER TABLE `academic_subject_teacher`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `account_admission_fee`
--
ALTER TABLE `account_admission_fee`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `account_exam_fee`
--
ALTER TABLE `account_exam_fee`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `exam_result`
--
ALTER TABLE `exam_result`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `hr_academic`
--
ALTER TABLE `hr_academic`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `hr_additional_and_deduction`
--
ALTER TABLE `hr_additional_and_deduction`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `hr_assigning_dept_head`
--
ALTER TABLE `hr_assigning_dept_head`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `hr_assigning_roster`
--
ALTER TABLE `hr_assigning_roster`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `hr_assigning_weekend`
--
ALTER TABLE `hr_assigning_weekend`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `hr_attendance`
--
ALTER TABLE `hr_attendance`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `hr_award_and_honors`
--
ALTER TABLE `hr_award_and_honors`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `hr_basic`
--
ALTER TABLE `hr_basic`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `hr_bonus`
--
ALTER TABLE `hr_bonus`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `hr_child`
--
ALTER TABLE `hr_child`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `hr_contact`
--
ALTER TABLE `hr_contact`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `hr_co_curricular_activities`
--
ALTER TABLE `hr_co_curricular_activities`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `hr_create_salary`
--
ALTER TABLE `hr_create_salary`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hr_experience`
--
ALTER TABLE `hr_experience`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `hr_family`
--
ALTER TABLE `hr_family`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `hr_job`
--
ALTER TABLE `hr_job`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `hr_job_posting`
--
ALTER TABLE `hr_job_posting`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `hr_leave`
--
ALTER TABLE `hr_leave`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `hr_leave_comment`
--
ALTER TABLE `hr_leave_comment`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `hr_loan`
--
ALTER TABLE `hr_loan`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `hr_nominee`
--
ALTER TABLE `hr_nominee`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `hr_previous_job_history`
--
ALTER TABLE `hr_previous_job_history`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `hr_reference`
--
ALTER TABLE `hr_reference`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `hr_research_and_publication`
--
ALTER TABLE `hr_research_and_publication`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `hr_salary_basic_info`
--
ALTER TABLE `hr_salary_basic_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hr_shift_schedule`
--
ALTER TABLE `hr_shift_schedule`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `hr_training`
--
ALTER TABLE `hr_training`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `li_admin`
--
ALTER TABLE `li_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `master_academic_exam`
--
ALTER TABLE `master_academic_exam`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `master_admission_fee`
--
ALTER TABLE `master_admission_fee`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `master_bank`
--
ALTER TABLE `master_bank`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `master_bank_branch`
--
ALTER TABLE `master_bank_branch`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `master_blood_group`
--
ALTER TABLE `master_blood_group`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `master_board`
--
ALTER TABLE `master_board`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `master_bonus`
--
ALTER TABLE `master_bonus`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `master_class`
--
ALTER TABLE `master_class`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `master_class_subject`
--
ALTER TABLE `master_class_subject`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `master_department`
--
ALTER TABLE `master_department`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `master_designation`
--
ALTER TABLE `master_designation`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `master_district`
--
ALTER TABLE `master_district`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `master_division`
--
ALTER TABLE `master_division`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `master_exam_degree`
--
ALTER TABLE `master_exam_degree`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `master_exam_fee`
--
ALTER TABLE `master_exam_fee`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `master_exam_name`
--
ALTER TABLE `master_exam_name`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `master_freedom_fighter_relation`
--
ALTER TABLE `master_freedom_fighter_relation`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `master_gender`
--
ALTER TABLE `master_gender`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `master_holiday`
--
ALTER TABLE `master_holiday`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `master_job_type`
--
ALTER TABLE `master_job_type`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `master_leave_type`
--
ALTER TABLE `master_leave_type`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `master_loan_type`
--
ALTER TABLE `master_loan_type`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `master_marital_status`
--
ALTER TABLE `master_marital_status`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `master_menu`
--
ALTER TABLE `master_menu`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `master_module`
--
ALTER TABLE `master_module`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `master_profession`
--
ALTER TABLE `master_profession`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `master_religion`
--
ALTER TABLE `master_religion`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `master_role`
--
ALTER TABLE `master_role`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `master_section`
--
ALTER TABLE `master_section`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `master_shift`
--
ALTER TABLE `master_shift`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `master_study_group`
--
ALTER TABLE `master_study_group`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `master_subject`
--
ALTER TABLE `master_subject`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `master_sub_menu`
--
ALTER TABLE `master_sub_menu`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `master_thana`
--
ALTER TABLE `master_thana`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `master_user`
--
ALTER TABLE `master_user`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `master_weekend`
--
ALTER TABLE `master_weekend`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `master_year`
--
ALTER TABLE `master_year`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `user_role_permission`
--
ALTER TABLE `user_role_permission`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2066;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
